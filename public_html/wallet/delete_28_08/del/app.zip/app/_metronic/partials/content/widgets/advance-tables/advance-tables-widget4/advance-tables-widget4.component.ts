import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advance-tables-widget4',
  templateUrl: './advance-tables-widget4.component.html',
})
export class AdvanceTablesWidget4Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
