import { Component } from '@angular/core';
import { AuthService } from '../../../../../../modules/auth/services/auth.service';
@Component({
  selector: 'app-tables-widget1',
  templateUrl: './tables-widget1.component.html',
})
export class TablesWidget1Component {
  constructor(private jobService: AuthService) {}
notification:any[];

  ngOnInit(): void {
   this.jobService.getallnotification()
          .subscribe(data => {
            console.log(data);

            this.notification = data;
console.log(data);
          });

      }
}
