import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthService } from '../modules/auth/services/auth.service';

import { User } from 'src/app/models/user.model';
// import { AuthService } from 'src/app/authentication/auth.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';



// *ngIf="authService.isSuperAdminAuthenticated()" 



@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class AllUsersComponent implements OnInit {

  dataSource: any;

  columnsToDisplay: any[];
  expandedElement: null;
  c = [];
  users: User[];
  page = 1;
  pageSize = 4;
  collectionSize: any;
  // users.length;

  loading: any;
  balance: any;
  testCount: any;
  user_id: any;
  otp: boolean = false;
  bal: boolean = false;
  deleteuser: FormGroup;
  constructor(private formBuilder: FormBuilder, public authService: AuthService, private router: Router, private jobService: AuthService, private _snackBar: MatSnackBar) {

  }




  ngOnInit() {

    this.deleteuser = this.formBuilder.group({
      id: [],
      otp: ['', Validators.required],
      user_id: [''],
    });

    this.loading = true;
    this.testCount = 1;

    // this.users = [{ id: 3 }];

    if (!window.localStorage.getItem('token')) {
      this.router.navigate(['login']);
      return;
    }
    let token = localStorage.getItem('token');



    this.jobService.getUsers()
      .subscribe(data => {

        this.users = data;
        console.log(this.users);
        this.collectionSize = this.users.length;


        this.testCount = this.users.length;
        this.dataSource = data;





        this.columnsToDisplay = ['id', 'first_name', 'last_name', 'email',
          'updated_at'];
        expandedElement: User;
        console.log(this.testCount);
        window.localStorage.removeItem("students");
        window.localStorage.setItem("students", this.testCount);

        this.loading = false;





      });
  }


  sendtostatus(id: any): void {

    // alert(id);

    this.jobService.changeStatus(+id)
      .subscribe(data => {
        //this.users = data;
        this._snackBar.open("Approved Successfully", "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'
        });



      });





  };


  sendtoaccountstatus(id: any): void {

    this.jobService.deleteaccountstatus(+id)
      .subscribe(data => {
        this.users = data.result;
        this._snackBar.open("Deleted Successfully", "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

      });

  }
  onSubmit1(id: any) {
    this.user_id = id;
    this.deleteuser.controls['user_id'].setValue(this.user_id);

    this.jobService.deleteuser(this.deleteuser.value)
      .subscribe(data => {

        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

      });
    this.otp = false;
  }

  deleteuserotp(id: any): void {
    this.otp = true;

    this.jobService.deleteuserotp()
      .subscribe(data => {

        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

      });




  }

  deleteg2f(email: any): void {

    this.jobService.deleteg2f(email)
      .subscribe(data => {

        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

      });

  }
  showbalance(wallet_name: any) {
    this.bal = false;
    this.jobService.showbalance(wallet_name)
      .subscribe(data => {

        console.log(data);
        this.balance = data;
        this.bal = true;

      });
  }

  newchangelogin1(id: any): void {


    
    console.log("data"+ id);

  }
  newchangelogin(id: any): void {


   
    console.log("data"+ id);


    this.jobService.changelogin(id)
      .subscribe(data => {



    console.log("data"+ id);

/*
        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

*/
 
        console.log( data);

        console.log(  data['access_token']);


        window.localStorage.removeItem("token");
        localStorage.setItem('token', data['access_token']);
        window.localStorage.removeItem("roll");
        window.localStorage.setItem("roll", data['user']['roll']);

        alert(data['user']['roll']); alert(data['user']['roll']); alert(data['user']['roll']); alert(data['user']['roll']); alert(data['user']['roll']);

        //this.router.navigate(['/dashboard-users'])


        /////////////////////////
        // console.log("user", data['user']['gauth']);
        // localStorage.setItem('token',  data['user']['access_token']);

        //  console.log("userroll", data['user']['roll']);
        window.localStorage.removeItem("roll");
        window.localStorage.setItem("roll", data['user']['roll']);

        // this.router.navigate([this.returnUrl]);

        //    this.router.navigate(['/investment']);


        //////////////////////////

      });

  }


  sendpayment(id: any) {
    window.localStorage.removeItem("paymentuser_id");
    window.localStorage.setItem("paymentuser_id", id);
    this.router.navigate(['/send-payment'])
  }
}
