import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthService } from '../modules/auth/services/auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-currency-exchange',
  templateUrl: './currency-exchange.component.html',
  styleUrls: ['./currency-exchange.component.scss']
})
export class CurrencyExchangeComponent implements OnInit {
  rate2_print: any; allbalance: any;
  msg: any; currencies: any; show: any;

  transactions: any;

  constructor(private _snackBar: MatSnackBar, private jobService: AuthService, private formBuilder: FormBuilder,) { }

  addForm: FormGroup;

  ngOnInit(): void {

    this.addForm = this.formBuilder.group({
      id: [],
      amount1: ['', Validators.required],
      amount2: ['', Validators.required],
      coin1: ['', Validators.required],
      coin2: ['', Validators.required],
    });


    this.currencies = this.getcurrencies();


    this.addForm.controls["coin1"].setValue("USDT");

    this.addForm.controls["coin2"].setValue("BRL");


    this.show = false;





    this.jobService.allbalance()
      .subscribe(data => {
        console.log("dataallbalance", data);
        this.allbalance = data;



        this.jobService.ExchangeOrders()
          .subscribe(data => {

            this.show = true;
            this.transactions = data;
            console.log(data);
          });





      });



  }

  onKey(event: any) {
    // without type info
    // this.addForm.value.coin1;
    // this.addForm.value.coin2;

    // alert(this.addForm.value.coin1);




    this.jobService.newRate(event.target.value, this.addForm.value.coin1, this.addForm.value.coin2)
      .subscribe(data => {
        console.log("data", data);


        this.addForm.controls["amount2"].setValue(data['amount2']);

      });




    /*
  if(this.addForm.value.coin1 == 'DBKN' && this.addForm.value.coin2 == 'BRL'){
    
    this.rate2_print = 0.1403 * event.target.value;
    
         this.addForm.controls["amount2"].setValue(this.rate2_print);
 }      */

  }

  setValue(value: any, side: any) {


    var balance = 0;




    for (let entry of this.allbalance) {


      if (entry.coin == this.addForm.value.coin1)
        balance = entry.balance * value / 100;


    }


    this.addForm.controls["amount1"].setValue(balance);

    this.jobService.newRate(balance, this.addForm.value.coin1, this.addForm.value.coin2)
      .subscribe(data => {
        console.log(data);


        this.addForm.controls["amount2"].setValue(data['amount2']);


      });

  }

  onSubmit() {

    this.jobService.currencyexchange(this.addForm.value)
      .subscribe(data => {
        console.log("data", data);
        this.msg = data['message'];



        this._snackBar.open(this.msg, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

        this.jobService.allbalance()
          .subscribe(data => {
            console.log("dataallbalance", data);
            this.allbalance = data;


          });

        this.jobService.ExchangeOrders()
          .subscribe(data => {

            this.transactions = data;
            console.log(data);
          });




      });

  }

  getcurrencies() {
    return [
      { id: 'BTC', name: 'BTC' },

      { id: 'BRL', name: 'BRL' },
      { id: 'USDT', name: 'USDT' },
      { id: 'DBKN', name: 'Dubai Koin' }
    ];
  }



}
