import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-users-list',
  templateUrl: './dashboard-users-list.component.html',
  styleUrls: ['./dashboard-users-list.component.scss']
})
export class DashboardUsersListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
