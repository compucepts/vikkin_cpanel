import { Component, OnInit } from '@angular/core';



import {Router} from "@angular/router";
import { Transaction } from 'src/app/models/transaction.model';

import { AuthService } from '../modules/auth/services/auth.service';


import { WalletService } from '../service/wallet.service';






@Component({
  selector: 'app-deposits',
  templateUrl: './deposits.component.html',
  styleUrls: ['./deposits.component.scss']
})
export class DepositsComponent implements OnInit {

  constructor(private router: Router, private jobService: AuthService) { }


   address:any[] ;
 
   addresslen:any;
sub:any;


 ngOnInit() {
    this.sub = this.jobService.alldepositaddress()
    .subscribe(data => {
       this.address = data ;
		 this.addresslen = data.length ;
		console.log(39);
		
		
    });
	
	console.log(40);
  }
  ngOnDestroy() {
    this.sub.unsubscribe()
	console.log(48);
  }
  
  
  
  
}
