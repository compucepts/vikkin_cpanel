import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DubaikoinDepositComponent } from './dubaikoin-deposit.component';

describe('DubaikoinDepositComponent', () => {
  let component: DubaikoinDepositComponent;
  let fixture: ComponentFixture<DubaikoinDepositComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DubaikoinDepositComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DubaikoinDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
