import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Params,  ParamMap} from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { WalletService } from '../service/wallet.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from "@angular/router";


import { AuthService } from '../modules/auth/services/auth.service';

@Component({
  selector: 'app-dubaikoin-deposit',
  templateUrl: './dubaikoin-deposit.component.html',
  styleUrls: ['./dubaikoin-deposit.component.scss']
})
export class DubaikoinDepositComponent implements OnInit {

  address:any[];
	pix_amount:any;
	transactionId:[];
		show:any;
   constructor(private jobService: AuthService, private router: Router, private _snackBar: MatSnackBar,private activatedRoute: ActivatedRoute,private formBuilder: FormBuilder) { }

  ngOnInit() {
	  
	 
	 this.show=false;
	  
	var  deposit_amount ={"amount":  window.localStorage.getItem("deposit_amount" ) };//;
	  
	  console.log(deposit_amount);
	  
	  
	  
	     this.jobService.dubaikoindepositaddress(deposit_amount)
		 
		 
      .subscribe(data => {
        this.address = data['address']['address'];
   //  this.show = true;
	 // this.transactionId=data['transactionId'];
	 // 
  
  // this.pix_amount =  window.localStorage.getItem("pix_request" );
  
  
   this.show=true;
  
  
	
	
      });
	  
	  
	   
		
  }

}
