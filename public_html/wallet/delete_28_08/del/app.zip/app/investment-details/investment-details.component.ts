
import { Component, IterableDiffers, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";




import { ActivatedRoute, Params, ParamMap } from "@angular/router";


import { AuthService } from '../modules/auth/services/auth.service';

 

import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

import { MatSnackBar } from '@angular/material/snack-bar';



@Component({
  selector: 'app-investment-details',
  templateUrl: './investment-details.component.html',
  styleUrls: ['./investment-details.component.scss']
})
export class InvestmentDetailsComponent implements OnInit {
  invest: any; allbalance: any; user: any; refer_link: any; investment_info: any;

  id: any; step1: any;

  constructor(private formBuilder: FormBuilder, private router: Router,
    private jobService: AuthService, private _snackBar: MatSnackBar,
    private modalService: NgbModal, private activatedRoute: ActivatedRoute) { }



  ngOnInit(): void {





  let id = this.activatedRoute.snapshot.params.id;


    
    this.jobService.investment_info(id)
      .subscribe(data => {
        console.log(data.message);

        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'
        });

        alert(data.investment_id);

        this.investment_info = data.investment;



      });
  }


  activate_investment(id: any) {






    this.jobService.activate_investment(id)
      .subscribe(data => {
        console.log(data.message);

        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'
        });

        alert(data.investment_id);

        this.investment_info = data.investment;



      });

  }


}
