import { Component, OnInit } from '@angular/core';
import { AuthService } from '../modules/auth/services/auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from "@angular/router";
@Component({
  selector: 'app-investment',
  templateUrl: './investment.component.html',
  styleUrls: ['./investment.component.scss']
})
export class InvestmentComponent implements OnInit {
  invest: any; allbalance: any; user: any; refer_link: any;investment_info:any;
  constructor(private router: Router, private jobService: AuthService, private _snackBar: MatSnackBar) { }

  ngOnInit(): void {

     
    
    this.jobService.investplanfetch()
      .subscribe(data => {
        console.log("data11", data);
        this.invest = data;


     




      });



     





    this.jobService.allbalance()
      .subscribe(data => {
        console.log("dataallbalance", data);
        this.allbalance = data;


      });

    this.jobService.getuserById()
      .subscribe(data => {
        console.log(data);
        this.user = data;

        this.refer_link = "Refer Link " + data.refer_link;

      });

  }


  sendtoinvest(id: any, amount: any) {

    this.router.navigate(['submit-investment',id]);


   alert(id);
   return "";

    amount = amount * 4.80;

    localStorage.setItem('amount', amount)



    this.jobService.investment(id)
      .subscribe(data => {
        console.log(data.message);

        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'
        });



        if (data.type == 'success') {
          this.router.navigate(['investment-report']);
        }
        else {


          this.router.navigate(['pix-deposit']);


        }



      });

  }

}
