import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { AuthService } from '../modules/auth/services/auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-list-plan',
  templateUrl: './list-plan.component.html',
  styleUrls: ['./list-plan.component.scss']
})
export class ListPlanComponent implements OnInit {
addForm: FormGroup;

  swapamountForm: FormGroup;
  msg: any; 
  custom_coin_balance: any;
 
  investments_plans: any;

  loading: any;
  constructor(private formBuilder: FormBuilder, private router: Router, private jobService: AuthService, private _snackBar: MatSnackBar) { }


  ngOnInit() {
       this.jobService.investments_plans()
          .subscribe(data => {
            console.log(data);

              this.investments_plans = data;

          });

  }

sendto(page: any){
// window.localStorage.removeItem("txid");
  //   window.localStorage.setItem('txid',id);
  this.router.navigate([page]);
}


edit_plan(id: any){
	window.localStorage.removeItem("pid");
    window.localStorage.setItem('pid',id);
  this.router.navigate(['edit-plan']);
}

delete_plan(id: any){
	this.jobService.delete_plan(id)
          .subscribe(data => {
            console.log(data);
             this.jobService.investments_plans()
          .subscribe(data => {
            console.log(data);

              this.investments_plans = data;

          });
          });

}
}