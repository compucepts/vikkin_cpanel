export class Plan {

    id: number;
   
  }
  