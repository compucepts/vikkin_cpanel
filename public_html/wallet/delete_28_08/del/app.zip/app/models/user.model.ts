export class User {

  id: number;
created_at:any;
category:any;
title:any;
details:any
roll:any;
first_name:any;
last_name:any;
company_name:string;
gauth:any;
message:any;
  
}
