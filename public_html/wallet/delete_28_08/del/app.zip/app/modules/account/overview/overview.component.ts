import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../modules/auth/services/auth.service';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
})
export class OverviewComponent implements OnInit {
  constructor(private jobService: AuthService) {}
user:any;
first_name:any;
last_name:any;
company_name:any;
mobile:any;
companySite:any;
country:any;
allowmarketing:any;
  ngOnInit(): void {

   this.jobService.getuserById()
      .subscribe(data => {
      	console.log(data);
      	this.user=data;
      this.first_name=data.first_name;
      this.last_name=data.last_name;
        this.company_name=data.company_name;
      this.mobile=data.mobile;
         this.companySite=data.companySite;
      this.country=data.country;
        this.allowmarketing=data.allowmarketing;
        //this.editForm.setValue(data);


      });
}
}
