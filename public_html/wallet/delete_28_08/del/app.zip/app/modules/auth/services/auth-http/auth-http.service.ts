import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserModel } from '../../models/user.model';
import { environment } from '../../../../../environments/environment';
import { AuthModel } from '../../models/auth.model';

const API_USERS_URL = `${environment.apiUrl}/auth`;


const API_URL = `${environment.apiUrl}`;



@Injectable({
  providedIn: 'root',
})
export class AuthHTTPService {



  private readonly baseUrl = `${environment.apiUrl}`;//"https://api.inwista.ltd/api/";



  constructor(private http: HttpClient) { }

  // public methods
  login(email: string, password: string, google_auth: string): Observable<any> {
    return this.http.post<AuthModel>(`${API_USERS_URL}/login`, {
      email,
      password, google_auth
    });
  }

  checkgoogleauth(email: string, password: string): Observable<any> {
    return this.http.post<any>(`${API_USERS_URL}/googleauthtest`, {
      email,
      password
    });
  }

  //  checkgoogleauth(body:any ): Observable<any> {
  //   return this.http.post(`${API_USERS_URL}/googleauthtest`, {
  //     body
  //     });
  // }





  // CREATE =>  POST: add a new user to the server
  createUser(user: UserModel): Observable<UserModel> {
    //  alert("fd00");
    return this.http.post<any>(this.baseUrl + '/auth/register_otp', user);
  }



  // Your server should check email => If email exists send link to the user and return true | If email doesn't exist return false
  forgotPassword(email: string): Observable<boolean> {
    return this.http.post<boolean>(`${API_USERS_URL}/forgetpassword`, {
      email,
    });
  }

  // Your server should check email => If email exists send link to the user and return true | If email doesn't exist return false
  setPassword(email: string, code: string, password: string): Observable<boolean> {
    return this.http.post<boolean>(`${API_USERS_URL}/resetforgetpassword`, {
      email, code, password
    });
  }


  getUserByToken(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<UserModel>(`${API_USERS_URL}/me`, {
      headers: httpHeaders,
    });
  }


  public refer_user_list(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/refer/referuser_list`, {
      headers: httpHeaders,
    });
  }
  public getallloginhistory(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/login_history`, {
      headers: httpHeaders,
    });
  }

  public allbalance(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/systemplan/allbalance`, {
      headers: httpHeaders,
    });
  }


  public profile_enable(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/enableg2f`, {
      headers: httpHeaders,
    });
  }

  public authcode(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/enableg2f`, data, {
      headers: httpHeaders,
    });
  }


  // ///

  /////


  public networkfee(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/v1/networkfee`, {
      headers: httpHeaders,
    });
  }
  public balance(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/wallet/Balance`, {
      headers: httpHeaders,
    });
  }



  public sendfund(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/wallet/sendFund`, data, {
      headers: httpHeaders,
    });
  }

  public dashboard(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/dashboard`, {
      headers: httpHeaders,
    });
  }
  public reset_api_key(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/reset_api_key`, {
      headers: httpHeaders,
    });
  }

  public send_payment(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/system/send_payment`, data, {
      headers: httpHeaders,
    });
  }

  public receive_payment(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/system/receive_payment`, data, {
      headers: httpHeaders,
    });
  }



  public NewWallet(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/wallet/NewWallet`, data, {
      headers: httpHeaders,
    });
  }


  public getDeleteUsers(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/delete_user_account_request`, {
      headers: httpHeaders,
    });
  }

  public deleteuserotp(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/deleteuserotp`, {
      headers: httpHeaders,
    });
  }


  public investmentsreportbyid(token: string, id: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/systemplan/investmentbyuser/` + id, {
      headers: httpHeaders,
    });
  }

  // List User


  public changeStatus(token: string, id: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/changeStatus?id=` + id, {
      headers: httpHeaders,
    });
  }


  public deleteaccountstatus(token: string, id: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/deleteaccount?id=` + id, {
      headers: httpHeaders,
    });
  }

  public deleteuser(token: string, user: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/admin/deleteuser`, user, {
      headers: httpHeaders,
    });
  }


  public newRate(token: string, amount1: any, coin1: any, coin2: any): Observable<any> {

    var data = { "amount1": amount1, "coin1": coin1, "coin2": coin2 };

    console.log(data);
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/system/newRate`, data, {
      headers: httpHeaders
    });
  }



  public deleteg2f(token: string, email: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/admin/deleteg2f?email=` + email, {
      headers: httpHeaders,
    });
  }
  // Admin / Set Pass


  public showbalance(token: string, id: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/BalancebygivenID/` + id, {
      headers: httpHeaders,
    });
  }

  public changelogin(token: string, id: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/admin/changelogin?id=` + id, {
      headers: httpHeaders,
    });
  }


  public setpassword(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/admin/setpassword`, data, {
      headers: httpHeaders,
    });
  }


















  public getUsers(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/users`, {
      headers: httpHeaders,
    });
  }


  // General Setting

  public getsettings(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/wallet/getsettings`, {
      headers: httpHeaders,
    });
  }

  public setsettings(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/postlogo`, data, {
      headers: httpHeaders,
    });
  }

  public postlogo(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/postlogo`, data, {
      headers: httpHeaders,
    });
  }


  // getuserById(): Observable<any> {
  //    return this.http.get<any>(this.baseUrl + 'auth/user');
  //  }

  public getuserById(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/user`, {
      headers: httpHeaders,
    });
  }

  public getallnotification(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/system_notification`, {
      headers: httpHeaders,
    });
  }
  // getallnotification(): Observable<Array<Transaction>> {
  //   return this.http.get<Array<Transaction>>(this.baseUrl + 'wallet/system_notification');
  // }



  public alldepositaddress(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/alldepositaddress`, {
      headers: httpHeaders,
    });
  }




  public alltransaction(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/transactions`, {
      headers: httpHeaders,
    });
  }

  public ExchangeOrders(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/ExchangeOrders`, {
      headers: httpHeaders,
    });
  }

  public get_all_deposit_history(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_URL}/wallet/pix_deposit_history`, {
      headers: httpHeaders,
    });
  }

  public pixdepositaddress(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/systemplan/pixdepositaddress`, data, {
      headers: httpHeaders
    });
  }


  public currencyexchange(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/system/currencyexchange`, data, {
      headers: httpHeaders
    });
  }

  public dubaikoindepositaddress(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/system/dubaikoindepositaddress`, data, {
      headers: httpHeaders
    });
  }



  public usdtdepositaddress(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/system/USDTTron`, data, {
      headers: httpHeaders
    });
  }


  //  updateProfile
  //   updateProfile(user: User): Observable<ApiResponse> {
  //   return this.http.post<ApiResponse>(this.baseUrl + 'auth/postprofile', user);
  // }

  //  accountStatus(id: number): Observable<ApiResponse> {
  //   return this.http.get<ApiResponse>(this.baseUrl + 'auth/' + 'accountStatus?id=' + id);

  // }




  public investplanfetch(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/systemplan/investplanfetch`, {
      headers: httpHeaders
    });
  }


  public investmentsreport(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/systemplan/investmentsreport`, {
      headers: httpHeaders
    });
  }

  public activate_investment(token: string, id: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/robot/investment/ActivateInvestment/` + id, {
      headers: httpHeaders
    });
  }



  public investment(token: string, id: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/systemplan/investment/` + id, {
      headers: httpHeaders
    });
  }
  public alldatetransaction(token: string, id: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/alldatetransaction?getdate=` + id, {
      headers: httpHeaders
    });
  }

  public fetchdate(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/datefetch`, {
      headers: httpHeaders
    });
  }


  public accountStatus(token: string, id: number): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/accountStatus?id=`, id, {
      headers: httpHeaders
    });
  }

  public addticket(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/system/add_ticket`, data, {
      headers: httpHeaders
    });
  }

  public ticket_list(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/ticket_list`, {
      headers: httpHeaders
    });
  }

  public ticket_addmessage(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/system/addticket_message`, data, {
      headers: httpHeaders
    });
  }
  public ticket_by_id(token: string, id: number): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/ticket_by_id/` + id, {
      headers: httpHeaders
    });
  }

  public getticket_message(token: string, id: number): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/system/getticket_message/` + id, {
      headers: httpHeaders
    });
  }

  //   addticket(user: User): Observable<ApiResponse> {
  //   return this.http.post<ApiResponse>(this.baseUrl + 'auth/system/add_ticket', user);
  // }



  // ticket_list(): Observable<Array<Transaction>> {
  //   return this.http.get<Array<Transaction>>(this.baseUrl + 'auth/system/ticket_list');
  // }


  // ticket_addmessage(user: User): Observable<ApiResponse> {
  //   return this.http.post<ApiResponse>(this.baseUrl + 'auth/system/addticket_message', user);
  // }


  // ticket_by_id(id: any): Observable<any> {
  //   return this.http.get<any>(this.baseUrl + 'auth/system/ticket_by_id/' + id);
  // }


  // getticket_message(id: any): Observable<Array<Transaction>> {
  //   return this.http.get<Array<Transaction>>(this.baseUrl + 'auth/system/getticket_message/' + id);
  // }

  // updatedocument(document: Document): Observable<ApiResponse> {
  //   return this.http.post<ApiResponse>(this.baseUrl + 'auth/postkycnew', document);
  // }

  public updatedocument(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/postkycnew`, data, {
      headers: httpHeaders
    });
  }

  public updateProfile(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/postprofile`, data, {
      headers: httpHeaders
    });
  }












  public addinvestmentplan(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/addinvestmentplan`, data, {
      headers: httpHeaders
    });
  }


  public delete_plan(token: string, id: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/systemplan/delete_plan?id=` + id, {
      headers: httpHeaders
    });
  }

  public editplanbyid(token: string, id: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/systemplan/edit_plan?id=` + id, {
      headers: httpHeaders
    });
  }

  public updateinvestmentplan(token: string, data: any): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<any>(`${API_USERS_URL}/systemplan/updateinvestmentplan`, data, {
      headers: httpHeaders
    });
  }

  send_fund_email_otp(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_URL}/wallet/send_fund_email_otp`, {
      headers: httpHeaders,
    });
  }

  public investments_plans(token: string): Observable<UserModel> {
    const httpHeaders = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.get<any>(`${API_USERS_URL}/systemplan/investplanfetch`, {
      headers: httpHeaders
    });
  }

}
