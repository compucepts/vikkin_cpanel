import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Params,  ParamMap} from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { WalletService } from '../service/wallet.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from "@angular/router";

import { AuthService } from '../modules/auth/services/auth.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnInit {

  constructor(private jobService: AuthService) { }
  notification:any;
  ngOnInit(): void {
	  
	  
	  
    this.jobService.getallnotification()
          .subscribe(data => {
            console.log(data);

          //  this.notification = data;
			
console.log(data);
          });
		  
		  
  }

}
