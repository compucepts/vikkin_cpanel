import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import { WalletService } from '../../service/wallet.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {animate, state, style, transition, trigger} from '@angular/animations';
import { Transaction } from 'src/app/models/transaction.model';


import { AuthService } from '../../modules/auth/services/auth.service';




@Component({
  selector: 'app-all-transactions',
  templateUrl: './all-transactions.component.html',
  styleUrls: ['./all-transactions.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class AllTransactionsComponent implements OnInit {
fetchdate:any;
 dataSource:any;
date:any;
	testCount:any;
  columnsToDisplay : any[];
  expandedElement: null;  

transactions : Transaction[];

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: AuthService,private _snackBar: MatSnackBar) { }

  ngOnInit() {


  	this.jobService.fetchdate()
      .subscribe( data => {
      
        this.fetchdate = data[0]['date'] ;
        
        	console.log(this.fetchdate);
      });
  }

  transaction_list(date:any){

    this.jobService.alldatetransaction(date)
      .subscribe( data => {
      
        this.transactions = data ;
        this.testCount= this.transactions.length;
        console.log("this.testCount",this.testCount);
//     this.dataSource = data;

// this.columnsToDisplay = ['id', 'type','amount','balance','coin',  'status', 'updated_at'  ];
// expandedElement: Transaction;  
      });
  }

}
