import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";


import { AuthService } from '../../modules/auth/services/auth.service';


import { MatSnackBar } from '@angular/material/snack-bar'; 

@Component({
  selector: 'app-login-history',
  templateUrl: './login-history.component.html',
  styleUrls: ['./login-history.component.css']
})
export class LoginHistoryComponent implements OnInit {
login_history:any;

  constructor(private formBuilder: FormBuilder, private router: Router, private jobService: AuthService, private _snackBar: MatSnackBar) { }

  ngOnInit() {
	   this.jobService.getallloginhistory()
          .subscribe(data => {
            console.log("login_history",data);

            this.login_history = data;
console.log( this.login_history);
          }); 
	  
  }
}
