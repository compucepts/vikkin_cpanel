import { Routes } from '@angular/router';
import { DepositsComponent } from '../deposits/deposits.component';
import { TransactionsComponent } from '../transactions/transactions.component';
import { ChangePasswordComponent } from '../change-password/change-password.component';
import { PixDepositComponent } from '../pix-deposit/pix-deposit.component';
import { PixQrcodeComponent } from '../pix-qrcode/pix-qrcode.component';
import { WithdrawComponent } from '../withdraw/withdraw.component';

 
import { WidthdrawReportComponent } from '../widthdraw-report/widthdraw-report.component';


import { NotificationsComponent } from '../notifications/notifications.component';



import { ProfileDetailsComponent } from '../profile-details/profile-details.component';
import { AllTransactionsComponent } from '../pages/all-transactions/all-transactions.component';

import { LoginHistoryComponent } from '../pages/login-history/login-history.component';


import { SupportTicketComponent } from '../pages/support/support-ticket/support-ticket.component';
import { TicketDetailsComponent } from '../pages/support/ticket-details/ticket-details.component';
import { TwoFactorAuthenticationComponent } from '../two-factor-authentication/two-factor-authentication.component';
import { TicketListComponent } from '../pages/support/ticket-list/ticket-list.component';




import { GeneralSettingComponent } from '../general-setting/general-setting.component';
// #fake-end#
import { AllUsersComponent } from '../all-users/all-users.component';
import { DashboardUsersComponent } from '../dashboard-users/dashboard-users.component';
import { DeleteUsersComponent } from '../delete-users/delete-users.component';
import { AddPlanComponent } from '../add-plan/add-plan.component';
import { ListPlanComponent } from '../list-plan/list-plan.component';
import { EditPlanComponent } from '../edit-plan/edit-plan.component';
import { DashboardUsersListComponent } from '../dashboard-users-list/dashboard-users-list.component';
import { InvestmentReportComponent } from '../investment-report/investment-report.component';
import { InvestmentComponent } from '../investment/investment.component';
import { ReferReportComponent } from '../refer-report/refer-report.component';
import { UsdtTronComponent } from '../usdt-tron/usdt-tron.component';


import { DubaikoinDepositComponent } from '../dubaikoin-deposit/dubaikoin-deposit.component';


import { CurrencyExchangeComponent } from '../currency-exchange/currency-exchange.component';


import { SubmitInvestmentComponent } from '../submit-investment/submit-investment.component';

import { InvestmentDetailsComponent } from '../investment-details/investment-details.component';



const Routing: Routes = [
  {
    path: 'dashboard1',
    loadChildren: () =>
      import('./dashboard/dashboard.module').then((m) => m.DashboardModule),
  },

  {
    path: 'submit-investment/:id',
    component: SubmitInvestmentComponent // <= Page component registration
  },
  {
  path: 'currency-exchange',
  component: CurrencyExchangeComponent // <= Page component registration
},
  
  {
    path: 'dubaikoin-deposit',
    component: DubaikoinDepositComponent // <= Page component registration
  },
  
   {
    path: 'usdt-tron',
    component: UsdtTronComponent // <= Page component registration
  },
     {
    path: 'refer-report',
    component: ReferReportComponent // <= Page component registration
  },
   {
    path: 'investment-report',
    component: InvestmentReportComponent // <= Page component registration
  },
  {
    path: 'investment',
    component: InvestmentComponent // <= Page component registration
  },


  {
    path: 'investment/:id',
    component: InvestmentDetailsComponent // <= Page component registration
  },


   {
    path: 'general-setting',
    component: GeneralSettingComponent // <= Page component registration
  },
    {
    path: 'two-factor-authentication',
    component: TwoFactorAuthenticationComponent // <= Page component registration
  },
  {
    path: 'dashboard-users-list',
    component: DashboardUsersListComponent // <= Page component registration
  },
   {
    path: 'add-plan',
    component: AddPlanComponent // <= Page component registration
  },
   {
    path: 'list-plan',
    component: ListPlanComponent // <= Page component registration
  },
    {
    path: 'edit-plan',
    component: EditPlanComponent // <= Page component registration
  },

   {
    path: 'all-users',
    component: AllUsersComponent // <= Page component registration
  },
   {
    path: 'dashboard-users2',
    component: DashboardUsersComponent // <= Page component registration
  },
    {
    path: 'delete-users',
    component: DeleteUsersComponent // <= Page component registration
  },
  
  
  
  {
    path: 'support-ticket',
    component: SupportTicketComponent // <= Page component registration
  },
    {
    path: 'two-factor-authentication',
    component: TwoFactorAuthenticationComponent // <= Page component registration
  },
  {
    path: 'ticket-details/:id',
    component:  TicketDetailsComponent // <= Page component registration
  },
  {
    path: 'ticket-list',
    component: TicketListComponent // <= Page component registration
  },
  {
    path: 'deposits',
    component: DepositsComponent // <= Page component registration
  },{
    path: 'login-history',
    component: LoginHistoryComponent // <= Page component registration
  },
  {
    path: 'transactions',
    component: TransactionsComponent // <= Page component registration
  },
  {
    path: 'profile-details',
    component: ProfileDetailsComponent // <= Page component registration
  },
   {
    path: 'all-transactions',
    component: AllTransactionsComponent // <= Page component registration
  },
  {
    path: 'change-password',
    component:  ChangePasswordComponent // <= Page component registration
  },
  {
    path: 'pix-deposit',
    component: PixDepositComponent // <= Page component registration
  },{
    path: 'widthdraw',
    component: WithdrawComponent // <= Page component registration
  },
   {
    path: 'widthdraw-report',
    component: WidthdrawReportComponent // <= Page component registration
  },
    {
    path: 'pix-qrcode',
    component: PixQrcodeComponent // <= Page component registration
  },
  
  
    {
    path: 'notifications',
    component: NotificationsComponent // <= Page component registration
  },
  
  
  
  
  
  {
    path: 'builder',
    loadChildren: () =>
      import('./builder/builder.module').then((m) => m.BuilderModule),
  },
  
  {
    path: 'crafted/pages/profile',
    loadChildren: () =>
      import('../modules/profile/profile.module').then((m) => m.ProfileModule),
  },
  {
    path: 'crafted/account',
    loadChildren: () =>
      import('../modules/account/account.module').then((m) => m.AccountModule),
  },
  {
    path: 'crafted/pages/wizards',
    loadChildren: () =>
      import('../modules/wizards/wizards.module').then((m) => m.WizardsModule),
  },
  {
    path: 'crafted/widgets',
    loadChildren: () =>
      import('../modules/widgets-examples/widgets-examples.module').then(
        (m) => m.WidgetsExamplesModule
      ),
  },
  {
    path: 'apps/chat',
    loadChildren: () =>
      import('../modules/apps/chat/chat.module').then((m) => m.ChatModule),
  },
  {
    path: '/dashboard-users',
    redirectTo: '/investments',
    pathMatch: 'full',
  }, {
    path: '/',
    redirectTo: '/investments',
    pathMatch: 'full',
  },
  {
   
    path: '**',
    redirectTo: 'error/404',
  },{
    path: '',
    redirectTo: '/crafted/account/overview',
  },
];

export { Routing };
