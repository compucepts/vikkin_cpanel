import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { first } from "rxjs/operators";


import { AuthService } from '../../../modules/auth/services/auth.service';

import { User } from 'src/app/models/user.model';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-support-ticket',
  templateUrl: './support-ticket.component.html',
  styleUrls: ['./support-ticket.component.css']
})
export class SupportTicketComponent implements OnInit {

  addForm: FormGroup;
  support: User[];
  panelOpenState = false;
  constructor(private formBuilder: FormBuilder, private router: Router, 
    private jobService: AuthService, private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    //alert("Df");
    this.jobService.ticket_list()
      .subscribe(data => {

        this.support = data;
        console.log(this.support);
      });

    this.addForm = this.formBuilder.group({
      id: [''],
      category: [''],
      title: [''],
      details: ['']
    });


  }

  onSubmit() {
    this.jobService.addticket(this.addForm.value)
      .subscribe(data => {

        console.log(data);
        this._snackBar.open("Add ticket Successfully", "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'
        });

        this.router.navigate(['/ticket-details', data['ticket_id']]);

      });


  }
  
  sendto(id:any) {

    this.router.navigate(['/ticket-details', id]);
  }
}
