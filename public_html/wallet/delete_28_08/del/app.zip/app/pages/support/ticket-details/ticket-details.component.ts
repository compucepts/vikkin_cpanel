import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";




import { ActivatedRoute, Params, ParamMap } from "@angular/router";


import { AuthService } from '../../../modules/auth/services/auth.service';


import { Xpub } from 'src/app/models/xpub.model';
import { map } from 'rxjs/operators';

import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-ticket-details',
  templateUrl: './ticket-details.component.html',
  styleUrls: ['./ticket-details.component.css']
})
export class TicketDetailsComponent implements OnInit {
  addForm: FormGroup;
  messages: any;
  title: any;
  category: any;
  details: any;
  ticket_id: any;
  id1: number;
  private sub: any;
  panelOpenState = false;
  constructor(private formBuilder: FormBuilder, private router: Router, private jobService: AuthService, private _snackBar: MatSnackBar, private modalService: NgbModal, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {

    this.id1 = this.activatedRoute.snapshot.params.id;
    console.log("id", this.id1)
    //alert(this.id1);

    this.jobService.ticket_by_id(+this.id1)
      .subscribe(data => {
        this.category = data['category'];
        this.details = data['details'];
        this.title = data['title'];
        console.log(data);
      });


    this.addForm = this.formBuilder.group({

      ticket_id: [this.id1, Validators.required],
      message: ['', Validators.required]


    });

    this.jobService.getticket_message(+this.id1)
      .subscribe(data => {
        this.messages = data;
      });

  }

  onSubmit() {
    this.jobService.ticket_addmessage(this.addForm.value)
      .subscribe(data => {

        this._snackBar.open("Add Successfully", "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });


        this.jobService.getticket_message(+this.id1)
          .subscribe(data => {
            this.messages = data;
          });



      });
  }



}
