import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { first } from "rxjs/operators";


import { AuthService } from '../../../modules/auth/services/auth.service';

import { User } from 'src/app/models/user.model';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-ticket-list',
  templateUrl: './ticket-list.component.html',
  styleUrls: ['./ticket-list.component.css']
})
export class TicketListComponent implements OnInit {

  support: User[];
  constructor(private formBuilder: FormBuilder, private router: Router, private jobService: AuthService, private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.jobService.ticket_list()
      .subscribe(data => {

        this.support = data;
        console.log(this.support);
      });
  }


  addticket() {

    this.router.navigate(['/support-ticket']);
  }


  sendto(id:any) {
// alert(id);
    this.router.navigate(['/ticket-details', id]);
  }
}
