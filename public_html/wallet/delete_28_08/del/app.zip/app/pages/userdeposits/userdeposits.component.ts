import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userdeposits',
  templateUrl: './userdeposits.component.html',
  styleUrls: ['./userdeposits.component.scss']
})
export class UserdepositsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
