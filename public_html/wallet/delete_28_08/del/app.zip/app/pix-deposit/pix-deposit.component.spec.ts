import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PixDepositComponent } from './pix-deposit.component';

describe('PixDepositComponent', () => {
  let component: PixDepositComponent;
  let fixture: ComponentFixture<PixDepositComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PixDepositComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PixDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
