import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Params,  ParamMap} from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { WalletService } from '../service/wallet.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from "@angular/router";


import { AuthService } from '../modules/auth/services/auth.service';




@Component({
  selector: 'app-pix-deposit',
  templateUrl: './pix-deposit.component.html',
  styleUrls: ['./pix-deposit.component.scss']
})
export class PixDepositComponent implements OnInit {

  pix_address:any;deposit_history:any;
show:boolean=false;
   addForm: FormGroup;
  constructor(private jobService: AuthService, private router: Router, private _snackBar: MatSnackBar,private activatedRoute: ActivatedRoute,private formBuilder: FormBuilder) { }

  ngOnInit() {


    var amount:any;
 
   amount = localStorage.getItem( 'amount');


if(!amount) amount="";

  	this.addForm = this.formBuilder.group({
      //id: [],
     
      amount: [ amount , Validators.required],
    });
	
	this.loadolddepositdata();

  }

   onSubmit() {
  window.localStorage.removeItem("pix_request");
 window.localStorage.setItem("pix_request", this.addForm.value.amount  );
 
 
 
this.router.navigate(['pix-qrcode']);	  
  }



USDTdeposit(){
  // alert(this.buyForm.value.amount);

       window.localStorage.removeItem("pix_request");
 window.localStorage.setItem("pix_request", this.addForm.value.amount  );
 
 
 
this.router.navigate(['usdt-tron']);
}


  loadolddepositdata()
{
	
 this.jobService.get_all_deposit_history()
          .subscribe(data => {
            console.log(data);

            this.deposit_history = data;
 
          });	
}


am(amount:any){
//alert(amount);
    this.addForm.controls["amount"].setValue(amount);
}



dubaikoindeposit(){
  
    window.localStorage.removeItem("pix_request");
 window.localStorage.setItem("pix_request", this.addForm.value.amount  );
this.router.navigate(['dubaikoin-deposit']);

}



}