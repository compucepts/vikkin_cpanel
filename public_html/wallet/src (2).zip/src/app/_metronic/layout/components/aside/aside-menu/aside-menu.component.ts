import { Component, OnInit } from '@angular/core';
import { environment } from '../../../../../../environments/environment';
 
 
 import { AuthService } from '../../../../../modules/auth/services/auth.service';

 
import { Router } from "@angular/router";


@Component({
  selector: 'app-aside-menu',
  templateUrl: './aside-menu.component.html',
  styleUrls: ['./aside-menu.component.scss'],
})
export class AsideMenuComponent implements OnInit {
  appAngularVersion: string = environment.appVersion;
  appPreviewChangelogUrl: string = environment.appPreviewChangelogUrl;

  constructor( private router: Router ,public authService: AuthService, ) {}

  ngOnInit(): void {

  var v=  this.authService.isUser();


  

  }
  
  sendto(page:any)
  {  
	          
			  this.router.navigateByUrl(page);

  }

    logout() {
    this.authService.logout();
    document.location.reload();
  }
}
