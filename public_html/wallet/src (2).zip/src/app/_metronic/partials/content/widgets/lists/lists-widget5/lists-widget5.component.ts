import { Component } from '@angular/core';
import { AuthService } from '../../../../../../modules/auth/services/auth.service';
@Component({
  selector: 'app-lists-widget5',
  templateUrl: './lists-widget5.component.html',
})
export class ListsWidget5Component {
	address:any[];
	addresslen:any;
  constructor(private jobService: AuthService) {}
  ngOnInit(): void {
      this.jobService.alldepositaddress()
    .subscribe(data => {
       this.address = data ;
		 this.addresslen = data.length ;
		console.log(39);
		
		
    });

}
}
