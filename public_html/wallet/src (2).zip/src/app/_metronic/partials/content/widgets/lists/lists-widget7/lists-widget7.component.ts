import { Component } from '@angular/core';

@Component({
  selector: 'app-lists-widget7',
  templateUrl: './lists-widget7.component.html',
})
export class ListsWidget7Component {
  constructor() {}
}
