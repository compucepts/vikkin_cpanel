import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { AuthService } from '../modules/auth/services/auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-plan',
  templateUrl: './add-plan.component.html',
  styleUrls: ['./add-plan.component.scss']
})
export class AddPlanComponent implements OnInit {

 constructor(private formBuilder: FormBuilder, private router: Router, private jobService: AuthService, private _snackBar: MatSnackBar) { }

  addForm: FormGroup;
  msg: any;
  ngOnInit() {

    this.addForm = this.formBuilder.group({
      id: [],
      name: ['', Validators.required],
      duration: ['', Validators.required],
      total_return: ['', Validators.required],
      minimum: ['', Validators.required],
      maximum: ['', Validators.required],

      activation_fee: ['', Validators.required],

    });

  }

  onSubmit() {
    this.jobService.addinvestmentplan(this.addForm.value)
      .subscribe(data => {
        this.msg = data['message'];
        this._snackBar.open(this.msg, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });
        // alert(data['Message'])
        this.router.navigate(['list-plan']);
      });
  }


}
