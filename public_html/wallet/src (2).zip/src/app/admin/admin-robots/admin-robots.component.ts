import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { Form, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthService } from '../../modules/auth/services/auth.service';

import { User } from 'src/app/models/user.model';
import { UserModel } from 'src/app/modules/auth/models/user.model';
// import { AuthService } from 'src/app/authentication/auth.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';

import { ActivatedRoute } from "@angular/router";



@Component({
  selector: 'app-admin-robots',
  templateUrl: './admin-robots.component.html',
  styleUrls: ['./admin-robots.component.scss']
})
export class AdminRobotsComponent implements OnInit {



  delete_robot_form: FormGroup;


  constructor(private formBuilder: FormBuilder, private router: Router,
    private jobService: AuthService, private _snackBar: MatSnackBar,
    private activatedRoute: ActivatedRoute) { }
  ngOnInit(): void {


    

    this.delete_robot_form = this.formBuilder.group({

      
      robot_id: ['', Validators.required],

      otp: ['', Validators.required]

    });



  }



  


  debit_credit_Frm_btn: boolean = true;

  investments: any; total_investments: any;
  showfetch_investments: boolean = false;

  screen_message:any;
  
  showinvestments: boolean = false;

  fetch_investments( ): void {

    this.screen_message="Request in process please wait...";

    this.jobService.fetch_all_investments ()
      .subscribe(data => {

        this.screen_message="";
        this.investments = data;



        this.total_investments = data.count;



        this.showfetch_investments = true;
      });

  }






  

  delete_robot(id: any): void {

 


this.delete_robot_form.controls["robot_id"].setValue(id);


this.jobService.delete_robot(this.delete_robot_form.value)
.subscribe(data => {
  //	alert(data.message);
  this._snackBar.open(data.message, "Close", {
    duration: 2000,

    verticalPosition: 'top',
    horizontalPosition: 'center'

  });

  this.delete_robot_form.controls["robot_id"].setValue("" );

  this.fetch_investments();
});


    /*
    this.jobService.delete_robot(+id)
      .subscribe(data => {
      //  this.users = data.result;
        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

      });


      this. fetch_investments( );
*/
  }



}

