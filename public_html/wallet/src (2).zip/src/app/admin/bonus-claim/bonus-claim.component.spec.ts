import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BonusClaimComponent } from './bonus-claim.component';

describe('BonusClaimComponent', () => {
  let component: BonusClaimComponent;
  let fixture: ComponentFixture<BonusClaimComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BonusClaimComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BonusClaimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
