
import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { Form, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthService } from '../../modules/auth/services/auth.service';

import { User } from 'src/app/models/user.model';
import { UserModel } from 'src/app/modules/auth/models/user.model';
// import { AuthService } from 'src/app/authentication/auth.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';

import { ActivatedRoute } from "@angular/router";





@Component({
  selector: 'app-bonus-claim',
  templateUrl: './bonus-claim.component.html',
  styleUrls: ['./bonus-claim.component.scss']
})
export class BonusClaimComponent implements OnInit {



  constructor(private formBuilder: FormBuilder, private router: Router,
    private jobService: AuthService, private _snackBar: MatSnackBar,
    private activatedRoute: ActivatedRoute) { }
  ngOnInit(): void {
  }







  bonus_claims: any;
  showbonus_claims: boolean = false;

  screen_message: any;


  fetch_bonus_claims(): void {

    this.screen_message = "Request in process please wait...";

    this.jobService.fetch_bonus_claims()
      .subscribe(data => {

        this.screen_message = "";
        this.bonus_claims = data.transactions;



        this.showbonus_claims = true;
      });

  }


}

