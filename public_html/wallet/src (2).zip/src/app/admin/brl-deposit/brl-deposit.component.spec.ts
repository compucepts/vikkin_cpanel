import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrlDepositComponent } from './brl-deposit.component';

describe('BrlDepositComponent', () => {
  let component: BrlDepositComponent;
  let fixture: ComponentFixture<BrlDepositComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BrlDepositComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrlDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
