import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthService } from 'src/app/modules/auth/services/auth.service';

import { User } from 'src/app/models/user.model';
import { UserModel } from 'src/app/modules/auth/models/user.model';
// import { AuthService } from 'src/app/authentication/auth.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';



@Component({
  selector: 'app-brl-deposit',
  templateUrl: './brl-deposit.component.html',
  styleUrls: ['./brl-deposit.component.scss']
})
export class BrlDepositComponent implements OnInit {


  constructor(private formBuilder: FormBuilder, public authService: AuthService, private router: Router, private jobService: AuthService, private _snackBar: MatSnackBar) {

  }


  ngOnInit(): void {
  }

  show_page_data:boolean=false;
  transaction_brl:any;

  fetchdeposits(): void {
 
     this.jobService.alltransactionAdmin()
       .subscribe(data => {
  
         this.transaction_brl = data.transaction_brl;
     
        this.show_page_data=true;
 
 
       });
   
 
   }

   
   sendpayment(id: any) { 
    window.open( '/debit-credit-user/'+id , '_blank');

 }
}
