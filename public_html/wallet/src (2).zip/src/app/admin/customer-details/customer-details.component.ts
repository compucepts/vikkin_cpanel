


import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthService } from '../../modules/auth/services/auth.service';

import { User } from 'src/app/models/user.model';
import { UserModel } from 'src/app/modules/auth/models/user.model';
// import { AuthService } from 'src/app/authentication/auth.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';

import { ActivatedRoute } from "@angular/router";




@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.scss']
})
export class CustomerDetailsComponent implements OnInit {


  currencies: any;
  debit_credit_Frm: FormGroup;

  user_id: any;


  constructor(private formBuilder: FormBuilder, private router: Router,
    private jobService: AuthService, private _snackBar: MatSnackBar,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {


    this.user_id = 159;//this.activatedRoute.snapshot.params.user_id;

    this.userinfobyid();
  }


  user: any;
  userinfobyid(): void {


    this.jobService.userinfobyid(this.user_id)
      .subscribe(data => {

        this.user = data;




      });

  }




}

