import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DebitCreditUserComponent } from './debit-credit-user.component';

describe('DebitCreditUserComponent', () => {
  let component: DebitCreditUserComponent;
  let fixture: ComponentFixture<DebitCreditUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DebitCreditUserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DebitCreditUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
