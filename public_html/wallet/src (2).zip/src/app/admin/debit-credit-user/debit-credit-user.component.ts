import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { Form, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthService } from '../../modules/auth/services/auth.service';

import { User } from 'src/app/models/user.model';
import { UserModel } from 'src/app/modules/auth/models/user.model';
// import { AuthService } from 'src/app/authentication/auth.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';

import { ActivatedRoute } from "@angular/router";



@Component({
  selector: 'app-debit-credit-user',
  templateUrl: './debit-credit-user.component.html',
  styleUrls: ['./debit-credit-user.component.scss']
})
export class DebitCreditUserComponent implements OnInit {

  currencies: any;
  debit_credit_Frm: FormGroup;
  speical_robot: FormGroup;
  widthdraw_completion_form: FormGroup;

  user_id: any;


  user_email: any;


  setpassword: FormGroup;


  loadpage: boolean = false;


  constructor(private formBuilder: FormBuilder, private router: Router,
    private jobService: AuthService, private _snackBar: MatSnackBar,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.user_email = "";


    this.loadpage = false;
    this.user_id = this.activatedRoute.snapshot.params.user_id;



    this.speical_robot = this.formBuilder.group({

      user_id: [this.user_id, Validators.required],
      amount: ['', Validators.required],

      otp: ['', Validators.required]

    });

    this.setpassword = this.formBuilder.group({

      user_id: [this.user_id, Validators.required],
      new_password: ['', Validators.required],
      confirm_password: ['', Validators.required],

      otp: ['', Validators.required]

    });

    this.debit_credit_Frm = this.formBuilder.group({

      user_id: [this.user_id, Validators.required],
      amount: ['', Validators.required],
      currency: ['', Validators.required],

      description: ['', Validators.required],
      reference_number: ['', Validators.required],


      type: ['', Validators.required]
    });



    this.widthdraw_completion_form = this.formBuilder.group({

      user_id: [this.user_id, Validators.required],
      description: ['', Validators.required],
      id: ['', Validators.required], status: ['', Validators.required],
      txn: ['', Validators.required]

    });




    this.currencies = this.getcurrencies();

    //this.fetch_transactions();

    // this.fetch_investments( );
    this.about_user(this.user_id);
    //
    //userinfobyid(id: any): Observable<any> {

    // this.jobService.isLoadingSubject.subscribe(this.loadpagecontents);


    // this.fetch_widthdraw_requests_for_user(this.user_id);


  }


  user_data: any;
  about_user(user_id: any): void {


    this.jobService.userinfobyid(user_id)
      .subscribe(data => {

        this.user_email = data.email;


        this.user_data = data;

        this.loadpage = true;
      });

  }



  debit_credit_Frm_btn: boolean = true;

  investments: any; total_investments: any;
  showfetch_investments: boolean = false;


  fetch_investments(): void {



    this.jobService.fetch_investments(this.user_id)
      .subscribe(data => {

        this.investments = data;


        this.showfetch_investments = true;

        this.total_investments = data.count;



      });

  }


  widthdraw_requests: any;
  total_widthdraw_requests: any;

  fetch_widthdraw_requests_for_user(user_id: any): void {



    this.jobService.fetch_widthdraw_requests_for_user(user_id)
      .subscribe(data => {

        this.widthdraw_requests = data;





      });

  }


  widthdraw_completion_form_submit(id: any) {


    this.widthdraw_completion_form.controls["id"].setValue(id);


    this.jobService.widthdraw_completion_form_submit(this.widthdraw_completion_form.value)
      .subscribe(data => {
        //	alert(data.message);
        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

        this.fetch_widthdraw_requests_for_user(this.user_id);
      });
  }



  fetch_speical_robot() {



    this.fetch_widthdraw_requests_for_user(this.user_id);

  }

  fetch_widthdraw_data() {



    this.fetch_widthdraw_requests_for_user(this.user_id);

  }





  speical_robot_submit() {



    this.jobService.speical_robot_submit(this.speical_robot.value)
      .subscribe(data => {
        //	alert(data.message);
        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

        this.fetch_transactions();
      });
  }


  onsetpasswordSubmit() {



    this.jobService.setpassword(this.setpassword.value)
      .subscribe(data => {
        //	alert(data.message);
        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

        this.fetch_transactions();
      });
  }




  onSubmit1(type: any) {
    this.debit_credit_Frm_btn = false;
    this.debit_credit_Frm.controls["type"].setValue(type);


    this.jobService.debit_credit_user(this.debit_credit_Frm.value)
      .subscribe(data => {
        //	alert(data.message);

        this.debit_credit_Frm_btn = true;


        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

        this.fetch_transactions();
      });
  }



  getcurrencies() {
    return [
      { id: 'BTC', name: 'BTC' },

      { id: 'BRL', name: 'BRL' },
      { id: 'USDT', name: 'USDT' },
      { id: 'DBIK', name: 'Dubai Koin' }
    ];
  }

  transactions: any;

  showfetch_transactions: boolean = false;


  fetch_transactions(): void {


    this.jobService.fetch_transactions(this.user_id)
      .subscribe(data => {

        this.transactions = data;
        this.showfetch_transactions = true;




      });

  }




}

