import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DebitUserComponent } from './debit-user.component';

describe('DebitUserComponent', () => {
  let component: DebitUserComponent;
  let fixture: ComponentFixture<DebitUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DebitUserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DebitUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
