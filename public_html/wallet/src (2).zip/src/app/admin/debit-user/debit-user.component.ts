import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-debit-user',
  templateUrl: './debit-user.component.html',
  styleUrls: ['./debit-user.component.scss']
})
export class DebitUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
