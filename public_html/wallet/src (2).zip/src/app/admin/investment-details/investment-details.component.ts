import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-investment-details',
  templateUrl: './investment-details.component.html',
  styleUrls: ['./investment-details.component.scss']
})
export class InvestmentDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
