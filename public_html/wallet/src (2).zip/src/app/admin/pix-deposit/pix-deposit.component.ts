import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pix-deposit',
  templateUrl: './pix-deposit.component.html',
  styleUrls: ['./pix-deposit.component.scss']
})
export class PixDepositComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
