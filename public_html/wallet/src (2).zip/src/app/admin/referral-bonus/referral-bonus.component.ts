 

import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthService } from 'src/app/modules/auth/services/auth.service';

import { User } from 'src/app/models/user.model';
import { UserModel } from 'src/app/modules/auth/models/user.model';
// import { AuthService } from 'src/app/authentication/auth.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';



@Component({
  selector: 'app-referral-bonus',
  templateUrl: './referral-bonus.component.html',
  styleUrls: ['./referral-bonus.component.scss']
})
export class ReferralBonusComponent implements OnInit {

 
  constructor(private formBuilder: FormBuilder, public authService: AuthService, private router: Router, private jobService: AuthService, private _snackBar: MatSnackBar) {

  }

  ngOnInit(): void {
  }
  show_page_data:boolean=false;
  referral_bonus:any;show_loading_message:any;

  fetchdeposits(): void {
    this.show_page_data=false;

    this.show_loading_message="Processing request kindly wait...";


     this.jobService.fetchreferral_bonusAdmin()
       .subscribe(data => {
        this.show_loading_message="";
  
        this.referral_bonus = data.referral_bonus_income;
        this.show_page_data=true;
 
 
       });
   
 
   }



   sendpayment(id: any) { 
    window.open( '/debit-credit-user/'+id , '_blank');

 }

 
}
