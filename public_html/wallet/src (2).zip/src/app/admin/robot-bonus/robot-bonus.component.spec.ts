import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RobotBonusComponent } from './robot-bonus.component';

describe('RobotBonusComponent', () => {
  let component: RobotBonusComponent;
  let fixture: ComponentFixture<RobotBonusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RobotBonusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RobotBonusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
