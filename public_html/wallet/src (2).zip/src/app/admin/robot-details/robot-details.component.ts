
import { Component, IterableDiffers, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";




import { ActivatedRoute, Params, ParamMap } from "@angular/router";


import { AuthService } from '../../modules/auth/services/auth.service';



import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-robot-details',
  templateUrl: './robot-details.component.html',
  styleUrls: ['./robot-details.component.scss']
})
export class RobotDetailsComponent implements OnInit {


  invest: any;

  allbalance: any;

  user: any;

  refer_link: any;

  investment_info: any;

  id: any;

  step1: any;

  donate_sell_btn: any;
  sell_form_show: any;
  transactions: any;

  robo_transactions: any;
  robo_transactions_data: any;


  constructor(private formBuilder: FormBuilder, private router: Router,
    private jobService: AuthService, private _snackBar: MatSnackBar,
    private modalService: NgbModal, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {


    // this.fetch_investments();


  }
  referral_wallet_transactions: any;
  screen_message: any;
  show_page_data: boolean = false;

  referral_wallet_bonus_transactions: any;
  wallet_transactions: any;
  fetch_investments(): void {


    let id = this.activatedRoute.snapshot.params.id;
    this.screen_message = "Request in process please wait...";

    this.jobService.fetch_robot_admin_by_id(id)
      .subscribe(data => {
        this.screen_message = "";
        this.show_page_data = true;

        console.log(data);

        this.investment_info = data.robot;

        this.referral_wallet_transactions = data.referral_wallet_transactions;

        this.referral_wallet_bonus_transactions = data.referral_wallet_bonus_transactions;

        this.wallet_transactions = data.wallet_transactions;

        // this.robot_info = data; 
      });



  }


  sendtoUser(id: any) {
 
    // this.router.navigate(['/debit-credit-user',id])
 
     window.open( '/debit-credit-user/'+id , '_blank');

  }




}
