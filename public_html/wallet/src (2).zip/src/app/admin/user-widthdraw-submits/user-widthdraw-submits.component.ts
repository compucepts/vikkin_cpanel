import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthService } from 'src/app/modules/auth/services/auth.service';

import { User } from 'src/app/models/user.model';
import { UserModel } from 'src/app/modules/auth/models/user.model';
// import { AuthService } from 'src/app/authentication/auth.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';



@Component({
  selector: 'app-user-widthdraw-submits',
  templateUrl: './user-widthdraw-submits.component.html',
  styleUrls: ['./user-widthdraw-submits.component.scss']
})
export class UserWidthdrawSubmitsComponent implements OnInit {

  widthdraw_completion_form:FormGroup;


  constructor(private formBuilder: FormBuilder, public authService: AuthService,
     private router: Router, private jobService: AuthService, private _snackBar: MatSnackBar) {

  }



  ngOnInit(): void {

    this.widthdraw_completion_form = this.formBuilder.group({

      user_id: ['', Validators.required],
      description: ['', Validators.required],
      id: ['', Validators.required],  status: ['', Validators.required],
      txn: ['', Validators.required]
  
    });
  
  }



  
  widthdraw_requests:any;
  total_widthdraw_request:any;

  showWidthdrawRequest:boolean=false;
  
  fetch_widthdraw_request( ): void {


    this.jobService.fetch_widthdraw_requests( )
      .subscribe(data => {

        this.widthdraw_requests = data;



        this.total_widthdraw_request = data.length;



        this.showWidthdrawRequest = true;
      });

  }

  sendpayment(id: any) {
 
    // this.router.navigate(['/debit-credit-user',id])
 
     window.open( '/debit-credit-user/'+id , '_blank');

  }

  widthdraw_completion_form_submit(id: any,user_id:any) {


    this.widthdraw_completion_form.controls["id"].setValue(id);



    this.widthdraw_completion_form.controls["user_id"].setValue(user_id);


    this.jobService.widthdraw_completion_form_submit(this.widthdraw_completion_form.value)
      .subscribe(data => {
        //	alert(data.message);
        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

        this.fetch_widthdraw_request( );
      });
  }

}
