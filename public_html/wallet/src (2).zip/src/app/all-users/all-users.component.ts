import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthService } from '../modules/auth/services/auth.service';

import { User } from 'src/app/models/user.model';
import { UserModel } from 'src/app/modules/auth/models/user.model';
// import { AuthService } from 'src/app/authentication/auth.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';



//import { UserModel } from '../models/user.model';


// *ngIf="authService.isSuperAdminAuthenticated()" 



@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class AllUsersComponent implements OnInit {

  dataSource: any;
  total_users: any = 0;
  columnsToDisplay: any[];
  expandedElement: null;
  c = [];
  users: User[];
  page = 1;
  pageSize = 4;
  collectionSize: any;
  // users.length;
  user_counts: any;
  loading: any;
  balance: any;
  testCount: any;


  total_logins: any; login_count: any;


  user_id: any;
  otp: boolean = false;
  bal: boolean = false;
  deleteuser: FormGroup; searchForm: FormGroup;

  widthdraw_completion_form:FormGroup;


  currencies: any;
  investments: any;

  total_investments: any;


  list_users:any;


  constructor(private formBuilder: FormBuilder, public authService: AuthService, private router: Router, private jobService: AuthService, private _snackBar: MatSnackBar) {

  }




  ngOnInit() {

    this.deleteuser = this.formBuilder.group({
      id: [],
      otp: ['', Validators.required],
      user_id: [''],
    });


    this.widthdraw_completion_form = this.formBuilder.group({

      user_id: [this.user_id, Validators.required],
      description: ['', Validators.required],
      id: ['', Validators.required],  status: ['', Validators.required],
      txn: ['', Validators.required]

    });


    this.searchForm = this.formBuilder.group({
      query: [''],
    });



    this.loading = true;
    this.testCount = 1;


    this.getAdminDashboard();



    // this.users = [{ id: 3 }];

    if (!window.localStorage.getItem('token')) {
      this.router.navigate(['login']);
      return;
    }
    let token = localStorage.getItem('token');


this.showTransaction=false;
    this.jobService.getUsers()
    .subscribe(data => {

    //  this.users = data;
      this.list_users =data;

      this.showTransaction=true;
      
    });

    /*
       this.jobService.getUsers()
         .subscribe(data => {
   
           this.users = data;
           console.log(this.users);
           this.collectionSize = this.users.length;
   
   
           this.testCount = this.users.length;
           this.dataSource = data;
   
   
   
   
   
           this.columnsToDisplay = ['id', 'first_name', 'last_name', 'email',
             'updated_at'];
           expandedElement: User;
           console.log(this.testCount);
           window.localStorage.removeItem("students");
           window.localStorage.setItem("students", this.testCount);
   
   
   
   
   
   
         });
   
   */





  }




  transactions_usdt: any;
  transaction_brl: any;
  transaction_dbik: any;
  showTransaction:boolean=false;
  
  getAdminDashboard(): void {

   
   
   /* this.jobService.fetch_all_investments()
      .subscribe(data => {

        this.investments = data;
        

      });

      */


    this.jobService.alltransactionAdmin()
      .subscribe(data => {

        this.transactions_usdt = data.transaction_usdt;
        this.transaction_brl = data.transaction_brl;
        this.transaction_dbik = data.transaction_dbik;
       this.showTransaction=true;


      });
 


    this.jobService.adminDashboard()
      .subscribe(data => {

        this.total_users = data.total_users;

        this.user_counts = data.user_counts;

        this.total_logins = data.total_logins;

        this.login_count = data.login_count;


        this.loading = false;
      });

  }





  showinvestments: boolean = false;

  fetch_investments( ): void {


    this.jobService.fetch_all_investments ()
      .subscribe(data => {

        this.investments = data;



        this.total_investments = data.count;



        this.showinvestments = true;
      });

  }









  showtransactions: boolean = false;
  total_transactions: any;
  transactions: any;
  fetch_transactions(user_id: any): void {


    this.jobService.fetch_transactions(user_id)
      .subscribe(data => {

        this.transactions = data;



        this.total_transactions = data.count;



        this.showtransactions = true;
      });

  }

  widthdraw_requests:any;
  total_widthdraw_request:any;

  showWidthdrawRequest:boolean=false;
  
  fetch_widthdraw_request( ): void {


    this.jobService.fetch_widthdraw_requests( )
      .subscribe(data => {

        this.widthdraw_requests = data;



        this.total_widthdraw_request = data.length;



        this.showWidthdrawRequest = true;
      });

  }



  showRecoveryRobot: boolean = false;
  total_recovery_robot: any;
  recovery_robots: any;
  fetch_recovery_robot( ): void {


    this.jobService.fetch_recovery_robot( )
      .subscribe(data => {

        this.recovery_robots = data;



        this.total_recovery_robot = data.length;



        this.showRecoveryRobot = true;
      });

  }



  sendtostatus(id: any): void {

    // alert(id);

    this.jobService.changeStatus(+id)
      .subscribe(data => {
        //this.users = data;
        this._snackBar.open("Approved Successfully", "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'
        });



      });





  };


  sendtoaccountstatus(id: any): void {

    this.jobService.deleteaccountstatus(+id)
      .subscribe(data => {
        this.users = data.result;
        this._snackBar.open("Deleted Successfully", "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

      });

  }
  onSubmit1(id: any) {
    this.user_id = id;
    this.deleteuser.controls['user_id'].setValue(this.user_id);

    this.jobService.deleteuser(this.deleteuser.value)
      .subscribe(data => {

        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

      });
    this.otp = false;
  }

  deleteuserotp(id: any): void {
    this.otp = true;

    this.jobService.deleteuserotp()
      .subscribe(data => {

        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

      });




  }

  deleteg2f(email: any): void {

    this.jobService.deleteg2f(email)
      .subscribe(data => {

        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

      });

  }
  showbalance(wallet_name: any) {
    this.bal = false;
    this.jobService.showbalance(wallet_name)
      .subscribe(data => {

        console.log(data);
        this.balance = data;
        this.bal = true;

      });
  }

  newchangelogin1(id: any): void {



    console.log("data" + id);

  }
  newchangelogin(id: any): void {



    console.log("data" + id);


    this.jobService.changelogin(id)

      .subscribe((user: UserModel | undefined) => {



        if (user) {
          console.log("user", user['gauth']);
          localStorage.setItem('token', user['access_token']);

          console.log("userroll", user['roll']);
          window.localStorage.removeItem("roll");
          window.localStorage.setItem("roll", user['roll']);

          // this.router.navigate([this.returnUrl]);

          this.router.navigate(['/investment']);

        }
        else {


          //   this.hasError = true;
        }


      });

  }

  debit_form: boolean = false;

  sendpayment(id: any) { 
     window.open( '/debit-credit-user/'+id , '_blank');

  }

  setpassword(id: any) {

    this.router.navigate(['/setpass', id])
  }





  search() {


    this.jobService.getUsersByQuery(this.searchForm.value.query)
      .subscribe(data => {

        this.users = data;
 
        console.log(this.users);
        this.collectionSize = this.users.length;


        this.testCount = this.users.length;
        this.dataSource = data;


        this.columnsToDisplay = ['id', 'first_name', 'last_name', 'email',
          'updated_at'];
        expandedElement: User;
        console.log(this.testCount);
        window.localStorage.removeItem("students");
        window.localStorage.setItem("students", this.testCount);

        this.loading = false;



      });




  }


  widthdraw_completion_form_submit(id: any) {


    this.widthdraw_completion_form.controls["id"].setValue(id);


    this.jobService.widthdraw_completion_form_submit(this.widthdraw_completion_form.value)
      .subscribe(data => {
        //	alert(data.message);
        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

        this.fetch_widthdraw_request( );
      });
  }


}
