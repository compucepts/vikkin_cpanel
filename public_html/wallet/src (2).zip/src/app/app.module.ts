import { NgModule, APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { ClipboardModule } from 'ngx-clipboard';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { InlineSVGModule } from 'ng-inline-svg-2';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthService } from './modules/auth/services/auth.service';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
// #fake-start#
import { MatTabsModule } from '@angular/material/tabs';
import { FakeAPIService } from './_fake/fake-api.service';
import { DepositsComponent } from './deposits/deposits.component';
import { UserdepositsComponent } from './pages/userdeposits/userdeposits.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { AllTransactionsComponent } from './pages/all-transactions/all-transactions.component';
import { SupportTicketComponent } from './pages/support/support-ticket/support-ticket.component';
import { TicketDetailsComponent } from './pages/support/ticket-details/ticket-details.component';

import { TicketListComponent } from './pages/support/ticket-list/ticket-list.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { PixDepositComponent } from './pix-deposit/pix-deposit.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { PixQrcodeComponent } from './pix-qrcode/pix-qrcode.component';
import { WithdrawComponent } from './withdraw2/withdraw.component';
import { ProfileDetailsComponent } from './profile-details/profile-details.component';





import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatBadgeModule } from '@angular/material/badge';
import { MatBottomSheetModule } from '@angular/material/bottom-sheet';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatStepperModule } from '@angular/material/stepper';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatNativeDateModule, MatRippleModule } from '@angular/material/core';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSliderModule } from '@angular/material/slider';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
// import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
// import { MatTabsModule } from '@angular/material/tabs';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatTreeModule } from '@angular/material/tree';
import { TwoFactorAuthenticationComponent } from './two-factor-authentication/two-factor-authentication.component';

import { GeneralSettingComponent } from './general-setting/general-setting.component';
import { AllUsersComponent } from './all-users/all-users.component';
import { DashboardUsersComponent } from './dashboard-users/dashboard-users.component';
import { DeleteUsersComponent } from './delete-users/delete-users.component';
import { AddPlanComponent } from './add-plan/add-plan.component';
import { ListPlanComponent } from './list-plan/list-plan.component';
import { EditPlanComponent } from './edit-plan/edit-plan.component';
import { DashboardUsersListComponent } from './dashboard-users-list/dashboard-users-list.component';
import { InvestmentComponent } from './investment/investment.component';
import { InvestmentReportComponent } from './investment-report/investment-report.component';
import { ReferReportComponent } from './refer-report/refer-report.component';
import { WidthdrawReportComponent } from './widthdraw-report/widthdraw-report.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { UsdtTronComponent } from './usdt-tron/usdt-tron.component';

import { DubaikoinDepositComponent } from './dubaikoin-deposit/dubaikoin-deposit.component';
import { CurrencyExchangeComponent } from './currency-exchange/currency-exchange.component';


import { IvyCarouselModule } from 'angular-responsive-carousel';
import { SubmitInvestmentComponent } from './submit-investment/submit-investment.component';
import { InvestmentDetailsComponent } from './investment-details/investment-details.component';
import { BuySellRobotComponent } from './buy-sell-robot/buy-sell-robot.component';
import { LoginHistoryV2Component } from './login-history-v2/login-history-v2.component';



import { AgGridModule } from 'ag-grid-angular';
import { WidgetComponent } from './widget/widget.component';
import { DebitUserComponent } from './admin/debit-user/debit-user.component';
import { DebitCreditUserComponent } from './admin/debit-credit-user/debit-credit-user.component';
import { CustomerDetailsComponent } from './admin/customer-details/customer-details.component';
//import { UserDetailsComponent } from './admin/user-details/user-details.component';
import { EthereumDepositComponent } from './ethereum-deposit/ethereum-deposit.component';
import { SpecialRobotComponent } from './special-robot/special-robot.component';
import { AdminRobotsComponent } from './admin/admin-robots/admin-robots.component';
import { RobotDetailsComponent } from './admin/robot-details/robot-details.component';
import { SendUsdtTokenComponent } from './send-usdt-token/send-usdt-token.component';
import { BonusClaimComponent } from './admin/bonus-claim/bonus-claim.component';
import { BrlDepositComponent } from './admin/brl-deposit/brl-deposit.component';
import { UsdtDepositComponent } from './admin/usdt-deposit/usdt-deposit.component';
import { UserWidthdrawSubmitsComponent } from './admin/user-widthdraw-submits/user-widthdraw-submits.component';
import { ReferralBonusComponent } from './admin/referral-bonus/referral-bonus.component';
import { RobotBonusComponent } from './admin/robot-bonus/robot-bonus.component';
 

 


// #fake-end#
export function HttpLoaderFactory(httpClient: HttpClient) {
  return new TranslateHttpLoader(httpClient);
}

function appInitializer(authService: AuthService) {
  return () => {
    return new Promise((resolve) => {
      //@ts-ignore
      authService.getUserByToken().subscribe().add(resolve);
    });
  };
}

@NgModule({
  declarations: [AppComponent, SupportTicketComponent,
    TicketDetailsComponent,
    TicketListComponent, DepositsComponent, UserdepositsComponent,
    AllTransactionsComponent, TransactionsComponent, ChangePasswordComponent,
    PixDepositComponent, PixQrcodeComponent, WithdrawComponent,
    ProfileDetailsComponent, TwoFactorAuthenticationComponent,

    GeneralSettingComponent, AllUsersComponent, DashboardUsersComponent,
    DeleteUsersComponent, AddPlanComponent, ListPlanComponent, EditPlanComponent,
    DashboardUsersListComponent, InvestmentComponent, InvestmentReportComponent,
    ReferReportComponent, WidthdrawReportComponent, NotificationsComponent,
    UsdtTronComponent, DubaikoinDepositComponent, CurrencyExchangeComponent,   
    SubmitInvestmentComponent, InvestmentDetailsComponent, BuySellRobotComponent,
    LoginHistoryV2Component, WidgetComponent, DebitUserComponent, 
    DebitCreditUserComponent, CustomerDetailsComponent, 
     EthereumDepositComponent, SpecialRobotComponent, AdminRobotsComponent, RobotDetailsComponent,
      SendUsdtTokenComponent, BonusClaimComponent, BrlDepositComponent, UsdtDepositComponent, UserWidthdrawSubmitsComponent, ReferralBonusComponent, RobotBonusComponent 



  ],
  imports: [
    BrowserModule,
    FormsModule, MatTabsModule,
    MatSnackBarModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    TranslateModule.forRoot(),
    HttpClientModule,
    ClipboardModule,
    NgxDropzoneModule,

    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatStepperModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,


    IvyCarouselModule,

    // #fake-start#
    environment.isMockEnabled
      ? HttpClientInMemoryWebApiModule.forRoot(FakeAPIService, {
        passThruUnknownUrl: true,
        dataEncapsulation: false,
      })


      : [], TranslateModule.forRoot({
        loader: {
          provide: TranslateLoader,
          useFactory: HttpLoaderFactory,
          deps: [HttpClient]
        }
      }),
    // #fake-end#
    AppRoutingModule,
    InlineSVGModule.forRoot(),
    NgbModule,

    AgGridModule,


  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: appInitializer,
      multi: true,
      deps: [AuthService],
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
