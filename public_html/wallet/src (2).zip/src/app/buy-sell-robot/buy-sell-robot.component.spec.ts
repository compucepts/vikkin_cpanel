import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuySellRobotComponent } from './buy-sell-robot.component';

describe('BuySellRobotComponent', () => {
  let component: BuySellRobotComponent;
  let fixture: ComponentFixture<BuySellRobotComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuySellRobotComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BuySellRobotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
