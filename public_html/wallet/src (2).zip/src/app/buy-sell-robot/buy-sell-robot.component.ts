
import { WalletService } from '../service/wallet.service';



import { Component, IterableDiffers, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";




import { ActivatedRoute, Params, ParamMap } from "@angular/router";


import { AuthService } from '../modules/auth/services/auth.service';



import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

import { MatSnackBar } from '@angular/material/snack-bar';




@Component({
  selector: 'app-buy-sell-robot',
  templateUrl: './buy-sell-robot.component.html',
  styleUrls: ['./buy-sell-robot.component.scss']
})
export class BuySellRobotComponent implements OnInit {


  investments: any[];
  id: any;
  refer_user_id: any;

  loadedfully: boolean;
  investments_buy: any;
  investments_your_listing: any;
  investments_purchase_history: any;
  count1: any;

  constructor(private formBuilder: FormBuilder, private router: Router,
    private jobService: AuthService, private _snackBar: MatSnackBar,
    private modalService: NgbModal, private activatedRoute: ActivatedRoute) { }
  panelOpenState = false;

  ngOnInit(): void {

    this.loadedfully = false;


    this.jobService.buy_sell_robots()
      .subscribe(data => {

        console.log(data);


        this.investments_buy = data['buy'];
        this.investments_your_listing = data['your_listing'];
        this.investments_purchase_history = data['purchase_history'];
        this.loadedfully = true;

      });
  }





  buy_this_robot(id: any) {



    this.jobService.buy_this_robot(id)
      .subscribe(data => {
        console.log(data.message);

        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'
        });

        this.ngOnInit();


      });



  }

  sendto(id: any) {
  //  alert(id);
  this.router.navigate(['/investment', id]);
  }



}
