import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import { WalletService } from '../service/wallet.service';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {

   constructor(private formBuilder: FormBuilder,private router: Router, private jobService: WalletService, private _snackBar: MatSnackBar) { }


  addForm: FormGroup;
ngOnInit() {
  this.addForm = this.formBuilder.group({
      id: [],
      current_password: ['', Validators.required], 
       new_password: ['', Validators.required],
        confirm_password: ['', Validators.required]
        
     
     
    });

  }

  onSubmit() {
    this.jobService.changepassword(this.addForm.value)
      .subscribe( data => {
      //	alert(data.message);
       this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });
    
      });
  }
}
