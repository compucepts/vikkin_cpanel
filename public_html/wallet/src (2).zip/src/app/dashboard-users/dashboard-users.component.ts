import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { AuthService } from '../modules/auth/services/auth.service';


import { Transaction } from 'src/app/models/transaction.model';

import { User } from 'src/app/models/user.model';
// import { createChart } from 'lightweight-charts';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
// import { ResizedEvent } from 'angular-resize-event';
import { MatSnackBar } from '@angular/material/snack-bar';

import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
// import { inherits } from 'util';

@Component({
  selector: 'app-dashboard-users',
  templateUrl: './dashboard-users.component.html',
  styleUrls: ['./dashboard-users.component.scss']
})
export class DashboardUsersComponent implements OnInit {

  transaction: Transaction[];
  panelOpenState = false;
  closeResult: string;
  editForm: FormGroup;
  addForm: FormGroup;


  newpayment: FormGroup;


  sendFund: FormGroup;
  title: string;
  receive_address: any;
  receive_coin: any;
  testCount: any;
  wallet_id: any;
  total_transaction: any;

  testCount1: any;

  url: string = "https://auth.lgbank.xyz/chart.html";
  urlSafe: SafeResourceUrl;
  total_deposit: any;
  current_membership: any;
  user_data:any; networkfee:any;
  current_plan:any;
  UnconfirmedTransactions:any; status:any;
  bnexx_balance:any;
  api_key:any; coin_name:any;
  msg: any; resulthash:any;
  coin_rate:any;

  networkfee_regular:any; networkfee_priority:any;
  id:any;

  hash:any; btc_address:any;
  btc_balance:any;
  bnexx_address:any;
USDTt:any; BTC:any;
  getRates:any;

  data:any;BRL:any;
  active:any;
  time_id: number = 0;
  width: number;
  height: number;
  lg:any;
  coin_name1:any;
  coin_name2:any;
  coin_name3:any;
  btc_rate:any;
  coin2_deposit_address:any;
pix_address:any;
allbalance:any;
  constructor(private _snackBar: MatSnackBar,
    public sanitizer: DomSanitizer, private formBuilder: FormBuilder,
    private router: Router, private jobService: AuthService, private modalService: NgbModal) { }
  ngOnInit() {

       this.jobService.allbalance()
      .subscribe(data => {
        console.log("dataallbalance",data);
this.allbalance= data;
  });
 this.width = window.screen.width;
 
  }

sendto(page:any){
   this.router.navigate([page]);
}
 


}

