import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { AuthService } from '../modules/auth/services/auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-edit-plan',
  templateUrl: './edit-plan.component.html',
  styleUrls: ['./edit-plan.component.scss']
})
export class EditPlanComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private router: Router, private jobService: AuthService, private _snackBar: MatSnackBar) { }
  id1: any;
  editForm: FormGroup;
  msg: any;
  ngOnInit() {
    let t = window.localStorage.getItem('pid');
    this.id1 = t;
    this.editForm = this.formBuilder.group({
      id: [],
      name: ['', Validators.required],
      duration: ['', Validators.required],
      total_return: ['', Validators.required],
      minimum: ['', Validators.required],
      maximum: ['', Validators.required],
      investment_amount: ['', Validators.required],
      activation_fee: [''],
      daily_bonus: []
    });
    this.jobService.editplanbyid(this.id1)
      .subscribe(data => {
        this.editForm.setValue(data);


      });
  }

  onSubmit() {
    this.jobService.updateinvestmentplan(this.editForm.value)
      .subscribe(data => {
        this.msg = data['message'];
        this._snackBar.open(this.msg, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });
        // alert(data['Message'])
        this.router.navigate(['list-plan']);
      });
  }


}
