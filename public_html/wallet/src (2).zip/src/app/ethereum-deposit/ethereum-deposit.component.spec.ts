import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EthereumDepositComponent } from './ethereum-deposit.component';

describe('EthereumDepositComponent', () => {
  let component: EthereumDepositComponent;
  let fixture: ComponentFixture<EthereumDepositComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EthereumDepositComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EthereumDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
