import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, ParamMap } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { WalletService } from '../service/wallet.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from "@angular/router";


import { AuthService } from '../modules/auth/services/auth.service';

@Component({
  selector: 'app-ethereum-deposit',
  templateUrl: './ethereum-deposit.component.html',
  styleUrls: ['./ethereum-deposit.component.scss']
})
export class EthereumDepositComponent implements OnInit {


  address: any[];
  pix_amount: any;
  transactionId: [];
  show: any;
  constructor(private jobService: AuthService, private router: Router, private _snackBar: MatSnackBar, private activatedRoute: ActivatedRoute, private formBuilder: FormBuilder) { }

  ngOnInit() {

    this.show = false;




    this.jobService.EthereumDeposit()


      .subscribe(data => {
        this.address = data['address'];

        this.show = true;


      });




  }
}
