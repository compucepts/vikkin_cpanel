
import { Component, IterableDiffers, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";




import { ActivatedRoute, Params, ParamMap } from "@angular/router";


import { AuthService } from '../modules/auth/services/auth.service';



import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

import { MatSnackBar } from '@angular/material/snack-bar';



@Component({
  selector: 'app-investment-details',
  templateUrl: './investment-details.component.html',
  styleUrls: ['./investment-details.component.scss']
})
export class InvestmentDetailsComponent implements OnInit {
  invest: any;

  allbalance: any;

  user: any;

  refer_link: any;

  investment_info: any;

  id: any;

  step1: any;

  donate_sell_btn: any;
  sell_form_show: any;
  transactions: any;

  robo_transactions: any;
  robo_transactions_data: any;

  constructor(private formBuilder: FormBuilder, private router: Router,
    private jobService: AuthService, private _snackBar: MatSnackBar,
    private modalService: NgbModal, private activatedRoute: ActivatedRoute) { }


  transactions_data: any;
  sell_robot_form: FormGroup;
  donate_form: FormGroup;
  activate_btn: any;

  activate_btn_disable: boolean = false;

  sell_it_btn_disable: boolean = false;

  donate_sell_btn_disable: boolean = false;
  update_investment_status_btn_disable: boolean = false;



  ngOnInit(): void {



    this.transactions_data = false;


    this.donate_sell_btn = false;

    let id = this.activatedRoute.snapshot.params.id;
    this.id = id;

    this.getinvestment(id);

    this.transaction_list();




    this.donate_form = this.formBuilder.group({

      robot_id: [this.id, Validators.required],

      email: ['', Validators.required],


    });

    this.sell_robot_form = this.formBuilder.group({

      robot_id: [this.id, Validators.required],


    });

    this.robot_income_daily_list();
  }

  getinvestment(id: any) {


    this.jobService.investmentinfobyid(id)
      .subscribe(data => {
        console.log(data.message);
        this.step1 = true;
        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'
        });




        this.investment_info = data;


        if (data.status != "Active"   ) {
          this.activate_btn = true;



          this.activate_btn_disable = false;
        }

        else {
          this.activate_btn = false;
        }


//
       // if (data.status == "pending"   && data.plan != 22)   {
       //   this.donate_sell_btn = true;
      //  }


      });


  }



  activate_investment(id: any) {

    this.activate_btn_disable = true;

    this.jobService.activate_investment(id)
      .subscribe(data => {
        console.log(data.message);

        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'
        });



        this.investment_info = data.investment;


        this.activate_btn_disable = false;
        this.getinvestment(id);

        this.transaction_list();


        this.router.navigate(['investment-report']);

      });



  }


  update_investment_status(id: any, status: any) {

    this.update_investment_status_btn_disable = true;


    this.jobService.update_investment_status(id, status)
      .subscribe(data => {
        console.log(data.message);

        this._snackBar.open(data.message, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'
        });




        this.update_investment_status_btn_disable = false;

        this.investment_info = data.investment;


        this.getinvestment(id);

        this.transaction_list();

        this.router.navigate(['investment-report']);
      });



  }


  robot_income_daily_list() {

    this.jobService.robot_income_daily(this.id)
      .subscribe(data => {

        this.robo_transactions = data;
        this.robo_transactions_data = true;
      });
  }


  transaction_list() {

    this.jobService.alltransaction()
      .subscribe(data => {

        this.transactions = data;
        this.transactions_data = true;
      });
  }


  sell_form_show_submit() {


    this.sell_it_btn_disable = true;


    this.jobService.sell_robot(this.sell_robot_form.value)
      .subscribe(data => {
        this.msg = data['message'];
        this._snackBar.open(this.msg, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

        this.router.navigate(['buy_sell_robots']);




      });


  }


  donate_investmentSubmit() {

    this.donate_sell_btn_disable = true;


    this.jobService.donate_robot(this.donate_form.value)
      .subscribe(data => {
        this.msg = data['message'];
        this._snackBar.open(this.msg, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });


        this.router.navigate(['investment-report']);


      });
  }







  sell_it_investment() {
    this.hide_all();

    this.sell_form_show = true;
  }


  donate_investment() {
    this.hide_all();

    this.donate_form_show = true;
  }


  hide_all() {
    //this.step1 = false;

    this.sell_form_show = false;
    this.donate_form_show = false;
  }


  donate_form_show: any;

  msg: any;
}
