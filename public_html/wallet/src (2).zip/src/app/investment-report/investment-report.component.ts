import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { AuthService } from '../modules/auth/services/auth.service';
import { WalletService } from '../service/wallet.service';

@Component({
  selector: 'app-investment-report',
  templateUrl: './investment-report.component.html',
  styleUrls: ['./investment-report.component.scss']
})
export class InvestmentReportComponent implements OnInit {


  investments: any[];
  id: any;
  refer_user_id: any;
  count1: any;

  showpage:boolean=false;

  nolink:boolean=false;


  constructor(private router: Router, private jobService: AuthService) { }

  ngOnInit() {

    let t = window.localStorage.getItem("refer_user_id");
    this.refer_user_id = t;
    if (this.refer_user_id != null) {
      //alert("Df00");
    
    
    
      this.jobService.investmentsreportbyid(this.refer_user_id)
        .subscribe(data => {

          this.investments = data;
          console.log(data);

          this.showpage=true;


          this.nolink=true;



          this.count1 = this.investments.length;
          window.localStorage.removeItem("refer_user_id");
        });


    }
    else {
      this.jobService.investmentsreport()
        .subscribe(data => {

          this.investments = data;
          console.log(data);
          this.count1 = this.investments.length;

          this.showpage=true;

          
          window.localStorage.removeItem("refer_user_id");
        });
    }
  }



  sendto(id: any) {
    // alert(id);

    if(!this.nolink)
        this.router.navigate(['/investment', id]);


  }


}
