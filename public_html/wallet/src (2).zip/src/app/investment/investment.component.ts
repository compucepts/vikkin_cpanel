import { Component, OnInit } from '@angular/core';
import { AuthService } from '../modules/auth/services/auth.service';


//import { AuthService } from '../modules/auth/services/auth.service';



import { AuthHTTPService } from '../modules/auth/services/auth-http';




import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from "@angular/router";
@Component({
  selector: 'app-investment',
  templateUrl: './investment.component.html',
  styleUrls: ['./investment.component.scss']
})
export class InvestmentComponent implements OnInit {
  invest: any; allbalance: any; user: any; refer_link: any; investment_info: any;


  investments: any; count1: any;
  investments_matured: any;
  dshowreport: any;
  showreport:Boolean=false;

  investments_active: any;
  total_users: any;
  investments_pending: any;
  constructor(private router: Router, private jobService: AuthService, private testService: AuthHTTPService, private _snackBar: MatSnackBar) { }

  ngOnInit(): void {


   





    this.testService.testcall("s").subscribe((data: any) => {

      this.invest = data;



    });





    this.jobService.allbalance()
      .subscribe(data => {
        this.showreport = true;
   // alert(this.showreport);
 
        this.allbalance = data;

    

      });

    this.jobService.getuserById()
      .subscribe(data => {
       

        this.showreport = true;
 


        this.user = data;

         
        this.refer_link = "Refer Link " + data.refer_link;

      });
    this.jobService.investmentsreport()
      .subscribe(data => {

        this.investments = data;
        this.showreport = true;
      


        this.count1 = this.investments.length;
 
      });




  }


  sendtoinvest(id: any, amount: any) {

    this.router.navigate(['submit-investment', id]);


  }




  sendto(id: any) {
    // alert(id);
    this.router.navigate(['/investment', id]);
  }


}
