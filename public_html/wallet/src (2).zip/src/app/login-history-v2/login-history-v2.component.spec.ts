import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginHistoryV2Component } from './login-history-v2.component';

describe('LoginHistoryV2Component', () => {
  let component: LoginHistoryV2Component;
  let fixture: ComponentFixture<LoginHistoryV2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginHistoryV2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginHistoryV2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
