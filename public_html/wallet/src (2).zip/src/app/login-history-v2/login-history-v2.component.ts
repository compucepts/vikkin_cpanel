




import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, ParamMap } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { WalletService } from '../service/wallet.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from "@angular/router";

import { AuthService } from '../modules/auth/services/auth.service';

@Component({
  selector: 'app-login-history-v2',
  templateUrl: './login-history-v2.component.html',
  styleUrls: ['./login-history-v2.component.scss']
})
export class LoginHistoryV2Component implements OnInit {
  showdatails: boolean;
  constructor(private jobService: AuthService) { }
  loginhistory: any;
  ngOnInit(): void {
    this.showdatails = false;


    this.jobService.getallloginhistory()
      .subscribe(data => {
        console.log(data);
        this.showdatails = true;
        this.loginhistory = data;

      });


  }

}
