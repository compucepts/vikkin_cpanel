export class ApiResponse {
  id:number;
    Error: any;
    status: any;
    message: any;
    result: any;  balance: any;
      Message: any;
      secret:any;   rate:any;api_key:any;
      rawresult:any;
      pix_address:any;
      transactionId:any;
  
      BTC:any;
  }
  