export class Transaction{

  id: number;
   date:any;
 type:any;
amount:any;
balance:any;
coin:any;
status:any;
updated_at:any;
description:any;
created_at:any;
}
