export class Xpub{

  id: number;
   

}
