import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../modules/auth/services/auth.service';
import { ActivatedRoute, Router } from "@angular/router";
@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
})
export class AccountComponent implements OnInit {
  constructor(private router: Router, private jobService: AuthService) { }
  user: any;
  allbalance: any;
  first_name: any;
  last_name: any;
  company_name: any;
  mobile: any;
  companySite: any;
  country: any;
  allowmarketing: any; refer_link: any;
  profile_pic: any;
  email: any;
  ngOnInit(): void {

    this.jobService.allbalance()
      .subscribe(data => {
        console.log("dataallbalance", data);
        this.allbalance = data;
      });

    this.jobService.getuserById()
      .subscribe(data => {
        console.log(data);
        this.user = data;
        this.first_name = data.first_name;
        this.last_name = data.last_name;
        this.company_name = data.company_name;
        this.mobile = data.mobile;
        this.companySite = data.companySite;
        this.country = data.country;
        this.email = data.email;
        this.allowmarketing = data.allowmarketing;
        this.profile_pic = data.profile_pic;
        //this.editForm.setValue(data);
        this.refer_link = "Refer Link " + data.refer_link;

      });
  }



  sendto(page: any) {
    this.router.navigate([page]);
  }

}