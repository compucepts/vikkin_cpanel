import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { AuthService } from '../../../../../modules/auth/services/auth.service';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatSnackBar } from '@angular/material/snack-bar';
import { first } from "rxjs/operators";
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
@Component({
  selector: 'app-profile-details',
  templateUrl: './profile-details.component.html',
})
export class ProfileDetailsComponent implements OnInit {
  isLoading$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  isLoading: boolean;
    editForm: FormGroup;

  private unsubscribe: Subscription[] = [];

  constructor( private _snackBar: MatSnackBar,private formBuilder: FormBuilder,private jobService: AuthService,private cdr: ChangeDetectorRef) {

    const loadingSubscr = this.isLoading$
      .asObservable()
      .subscribe((res) => (this.isLoading = res));
    this.unsubscribe.push(loadingSubscr);
  }

  ngOnInit(): void {


  }

  saveSettings() {
    this.isLoading$.next(true);
    setTimeout(() => {
      this.isLoading$.next(false);
      this.cdr.detectChanges();
    }, 1500);
  }

  ngOnDestroy() {
    this.unsubscribe.forEach((sb) => sb.unsubscribe());
  }

   onSubmit() {
      
    this.jobService.updateProfile(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if (data.status === 200) {


            //this.router.navigate(['job/center-list']);
          } else {

            this._snackBar.open("Update Profile Successfully", "Close", {
              duration: 2000,

              verticalPosition: 'top',
              horizontalPosition: 'center'
            });
          }
        },
        error => {
          alert(error);
        });

  }

}
