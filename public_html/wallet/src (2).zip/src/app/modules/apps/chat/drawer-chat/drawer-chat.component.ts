import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drawer-chat',
  templateUrl: './drawer-chat.component.html',
  styleUrls: ['./drawer-chat.component.scss'],
})
export class DrawerChatComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
