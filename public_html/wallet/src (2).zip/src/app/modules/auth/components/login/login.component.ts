import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription, Observable } from 'rxjs';
import { first } from 'rxjs/operators';
import { UserModel } from '../../models/user.model';
import { AuthService } from '../../services/auth.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

import { environment } from 'src/environments/environment';


 

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit, OnDestroy {
  // KeenThemes mock, change it to:
  defaultAuth: any = {
    email: '',
    password: '',
  };
  loginForm: FormGroup;
  hasError: boolean;
  returnUrl: string;
  isLoading$: Observable<boolean>;
  gauth: boolean = false;
  hideloginbtn: any;

  public appName = `${environment.appName}`;

  user: any;
  otpverify: any;
  otp: any;
  msg: any;
  message: any;
  // private fields
  private unsubscribe: Subscription[] = []; // Read more: => https://brianflove.com/2016/12/11/anguar-2-unsubscribe-observables/

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router, private _snackBar: MatSnackBar
  ) {
    this.isLoading$ = this.authService.isLoading$;
    // redirect to home if already logged in
    if (this.authService.currentUserValue) {
      // this.router.navigate(['/']);


      this.router.navigate(['/investment']);
    }
  }

  ngOnInit(): void {
    this.initForm();
    // get return url from route parameters or default to '/'
    this.returnUrl =
      this.route.snapshot.queryParams['returnUrl'.toString()] || '/';
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.loginForm.controls;
  }

  initForm() {
    this.loginForm = this.fb.group({


      email: [
        this.defaultAuth.email,
        Validators.compose([
          Validators.required,
          Validators.email,
          Validators.minLength(3),
          Validators.maxLength(320), // https://stackoverflow.com/questions/386294/what-is-the-maximum-length-of-a-valid-email-address
        ]),
      ],

      google_auth: [

        // Validators.compose([
        //   Validators.required,

        //   Validators.minLength(5),
        //   Validators.maxLength(5), // https://stackoverflow.com/questions/386294/what-is-the-maximum-length-of-a-valid-email-address
        // ]),
      ],


      password: [
        this.defaultAuth.password,
        Validators.compose([
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(100),
        ]),
      ],
    });
  }


  checkGAUTHorLogin() {
    // alert("sf");
    const loginSubscr = this.authService
      .checkgoogleauth(this.f.email.value, this.f.password.value)
      .subscribe(data => {
        console.log("data", data);

        if (data['Error']) {
          this.msg = data['message'];
          this._snackBar.open(this.msg, "Close", {
            duration: 2000,

            verticalPosition: 'top',
            horizontalPosition: 'center'

          });

          return;
        }

        if (data['emailconfirm']) {
          this.msg = data['message'];


          this._snackBar.open(this.msg, "Close", {
            duration: 2000,

            verticalPosition: 'top',
            horizontalPosition: 'center'

          });
          this.otpverify = true;
          this.hideloginbtn = false;


          return;

        }
        if (data['gauth']) {
          //  alert(data['gauth']);
          this.gauth = true;


        }
        else {

          this.submit();

          // localStorage.setItem('token', data['access_token']);

          //  console.log("userroll",data['roll']);
          //   window.localStorage.removeItem("roll");
          //   window.localStorage.setItem("roll", data['roll']);

          //   this.router.navigate([this.returnUrl]);

        }







      });
  }

  signInWithGoogleAuth() {


    this.authService
      .googleauthverify(this.f.email.value, this.f.password.value, this.f.google_auth.value)
      .subscribe((data) => {
        this.msg = data['message'];




        this._snackBar.open(this.msg, "Close", {
          duration: 2000,

          verticalPosition: 'top',
          horizontalPosition: 'center'

        });

        if (data['user']['roll']) {
          this.submit();


        }

      });
  }

  submit() {


    this.hasError = false;


    const loginSubscr = this.authService
      .login(this.f.email.value, this.f.password.value, this.f.google_auth.value)
      .pipe(first())
      .subscribe((user: UserModel | undefined) => {

        if (user) {
          console.log("user", user['gauth']);
          localStorage.setItem('token', user['access_token']);

          console.log("userroll", user['roll']);
          window.localStorage.removeItem("roll");
          window.localStorage.setItem("roll", user['roll']);

          // this.router.navigate([this.returnUrl]);

          this.router.navigate(['/investment']);

        }
        else {


          this.hasError = true;
        }
      });


    this.unsubscribe.push(loginSubscr);
  }

  ngOnDestroy() {
    this.unsubscribe.forEach((sb) => sb.unsubscribe());
  }
}
