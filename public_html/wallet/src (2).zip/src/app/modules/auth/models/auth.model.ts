export class AuthModel {
  authToken: string;
  refreshToken: string;
  expiresIn: Date;
  access_token: string;
  roll: any;
  gauth: any;
  message: any;
  setAuth(auth: AuthModel) {
    this.authToken = auth.authToken;
    this.access_token = auth.access_token;
    this.refreshToken = auth.refreshToken;
    this.expiresIn = auth.expiresIn;
    this.gauth = auth.gauth;
  }
}
