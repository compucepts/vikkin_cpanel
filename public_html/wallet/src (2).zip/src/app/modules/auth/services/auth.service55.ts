import { Injectable, OnDestroy } from '@angular/core';
import { Observable, BehaviorSubject, of, Subscription } from 'rxjs';
import { map, catchError, switchMap, finalize } from 'rxjs/operators';
import { UserModel } from '../models/user.model';
import { AuthModel } from '../models/auth.model';
import { AuthHTTPService } from './auth-http';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
const API_USERS_URL = `${environment.apiUrl}/auth`;
import { HttpClient, HttpHeaders } from '@angular/common/http';

export type UserType = UserModel | undefined;

@Injectable({
  providedIn: 'root',
})
export class AuthService implements OnDestroy {
  // private fields
  private unsubscribe: Subscription[] = []; // Read more: => https://brianflove.com/2016/12/11/anguar-2-unsubscribe-observables/
  private authLocalStorageToken = `${environment.appVersion}-${environment.USERDATA_KEY}`;
  private readonly baseUrl="https://api.inwista.ltd/api/";
  // public fields
  currentUser$: Observable<UserType>;
  isLoading$: Observable<boolean>;
  currentUserSubject: BehaviorSubject<UserType>;
  isLoadingSubject: BehaviorSubject<boolean>;

  get currentUserValue(): UserType {
    return this.currentUserSubject.value;
  }

  set currentUserValue(user: UserType) {
    this.currentUserSubject.next(user);
  }

  constructor(
    private authHttpService: AuthHTTPService,
    private router: Router,private http: HttpClient
  ) {
    this.isLoadingSubject = new BehaviorSubject<boolean>(false);
    this.currentUserSubject = new BehaviorSubject<UserType>(undefined);
    this.currentUser$ = this.currentUserSubject.asObservable();
    this.isLoading$ = this.isLoadingSubject.asObservable();
    const subscr = this.getUserByToken().subscribe();
    this.unsubscribe.push(subscr);
  }


  checkgoogleauth(email: string, password: string    ): Observable<any> {
    return this.http.post<any>(`${API_USERS_URL}/googleauthtest`, {
      email,
      password
    });
  }

  googleauthverify(email: string, password: string  ,two_factor_auth : string  ): Observable<any> {
    return this.http.post<any>(`${API_USERS_URL}/googleauthverify`, {
      email,
      password,
      two_factor_auth
    });
  }


  // public methods
  login(email: string, password: string, two_factor_auth : string ): Observable<UserType> {
    this.isLoadingSubject.next(true);
    return this.authHttpService.login(email, password,  two_factor_auth).pipe(
      map((auth: AuthModel) => {
        const result = this.setAuthFromLocalStorage(auth);
        return result;
      }),
      switchMap(() => this.getUserByToken()),
      catchError((err) => {
        console.error('err', err);
        return of(undefined);
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
  }

  //   checkgoogleauth(email: string, password: string ): Observable<UserType> {
  //   this.isLoadingSubject.next(true);
  //   return this.authHttpService.checkgoogleauth(email, password).pipe(
  //     map((auth: AuthModel) => {
  //       const result = this.setAuthFromLocalStorage(auth);
  //       console.log("result",result);
  //       return result;
  //     }),
  //     switchMap(() => this.getUserByToken()),
  //     catchError((err) => {
  //       console.error('err', err);

  //       return of(undefined);
  //     }),
  //     finalize(() => this.isLoadingSubject.next(false))
  //   );

  //    console.log("resultrr");
  // }
  
  
 // checkgoogleauth(body :any) {
 //    this.isLoadingSubject.next(true);
 //    return this.authHttpService.checkgoogleauth(body).pipe(
 //      map((auth: AuthModel) => {
 //        const result = this.setAuthFromLocalStorage(auth);
 //        return result;
 //      }),
 //      switchMap(() => this.getUserByToken()),
 //      catchError((err) => {
 //        console.error('err', err);
 //        return of(undefined);
 //      }),
 //      finalize(() => this.isLoadingSubject.next(false))
 //    );
 //  }

  
  logout() {
    localStorage.removeItem(this.authLocalStorageToken);
    this.router.navigate(['/auth/login'], {
      queryParams: {},
    });
  }

  getUserByToken(): Observable<UserType> {
    const auth = this.getAuthFromLocalStorage();
    if (!auth || !auth.authToken) {
      return of(undefined);
    }

    this.isLoadingSubject.next(true);
	
    return this.authHttpService.getUserByToken(auth.authToken).pipe(
      map((user: UserType) => {
        if (user) {
          this.currentUserSubject.next(user);
        } else {
          this.logout();
        }
        return user;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
	
	
  }



  getallloginhistory(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.getallloginhistory(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
  }
  
  allbalance(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.allbalance(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
  
  
  
  
  
  }
  
  getuserById(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.getuserById(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
  
  
  
  
  
  }
 getallnotification(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.getallnotification(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
  
  
  
  
  
  }
 

  updateProfile(data: any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }
    this.isLoadingSubject.next(true);
  var token=auth.authToken;
  return this.authHttpService.updateProfile(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
  }


  updatedocument(data: any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }
    this.isLoadingSubject.next(true);
  var token=auth.authToken;
  return this.authHttpService.updatedocument(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
  }
 fetchdate(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }
    this.isLoadingSubject.next(true);
  var token=auth.authToken;
  return this.authHttpService.fetchdate(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
  }
refer_user_list(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }
    this.isLoadingSubject.next(true);
  var token=auth.authToken;
  return this.authHttpService.refer_user_list(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
  }
   alldatetransaction(data: any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }
    this.isLoadingSubject.next(true);
  var token=auth.authToken;
  return this.authHttpService.alldatetransaction(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
  }

  accountStatus(data: any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }
    this.isLoadingSubject.next(true);
  var token=auth.authToken;
  return this.authHttpService.accountStatus(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
  }
alldepositaddress(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

	 
	 
    this.isLoadingSubject.next(true);
	
	
	 var token=auth.authToken;
	
 
	
	return this.authHttpService.alldepositaddress(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
	
	
	
	
	
  }
  
    
get_all_deposit_history(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

	 
	 
    this.isLoadingSubject.next(true);
	
	
	 var token=auth.authToken;
	
 
	
	return this.authHttpService.get_all_deposit_history(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
	
	
	
	
	
  }
alltransaction(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

	 
	 
    this.isLoadingSubject.next(true);
	
	
	 var token=auth.authToken;
	
 
	
	return this.authHttpService.alltransaction(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
	
	
	
	
	
  }
  
  
    
pixdepositaddress(data: any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

	 
	 
    this.isLoadingSubject.next(true);
	
	
	 var token=auth.authToken;
	
 
	
	return this.authHttpService.pixdepositaddress(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
	
	
	
	
	
  }
  
  
  
pixdepositaddress11(data: any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

	 
	 
    this.isLoadingSubject.next(true);
	

 var token=auth.authToken;
	
 
	
	return this.authHttpService.pixdepositaddress(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
	
	
  }
investment(id: any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  

 var token=auth.authToken;
  
 
  
  return this.authHttpService.investment(auth.authToken,id).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
  
  
  }

investmentsreport(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.investmentsreport(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }
investplanfetch(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.investplanfetch(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }


profile_enable(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.profile_enable(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

  deleteuserotp(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.deleteuserotp(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

  getDeleteUsers(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.getDeleteUsers(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }


  reset_api_key(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.reset_api_key(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

  dashboard(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.dashboard(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

 balance(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.balance(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

 networkfee(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.networkfee(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }


  sendfund(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.sendfund(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

  send_payment(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.send_payment(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }


receive_payment(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.receive_payment(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

NewWallet(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.changeStatus(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

   changeStatus(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.changeStatus(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

   deleteaccountstatus(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.deleteaccountstatus(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }


  deleteuser(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.deleteuser(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }


deleteg2f(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.deleteg2f(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

showbalance(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.showbalance(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

changelogin(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.changelogin(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

 setpassword(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.setpassword(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

  getUsers(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.getUsers(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }



 isSuperAdminAuthenticated() {
    let roll = JSON.parse(window.localStorage.getItem("roll")!);


    return parseInt(roll) == 12;

  }
  // General Setting


   
   getsettings(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.getsettings(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

   setsettings(data: any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.setsettings(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }
postlogo(data: any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.postlogo(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

   
authcode(data: any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.authcode(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

  
  

  // need create new user then login
  registration(user: UserModel): Observable<any> {
    //alert("bbn");
    this.isLoadingSubject.next(true);
	
	
    return this.authHttpService.createUser(user).pipe(
      map(() => {
        this.isLoadingSubject.next(false);
      }),
      switchMap(() => this.login(user.email, user.password, user.two_factor_auth )),
      catchError((err) => {
        console.error('err', err);
        return of(undefined);
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );
	
	
	
  }

  forgotPassword(email: string): Observable<boolean> {
    this.isLoadingSubject.next(true);
    return this.authHttpService
      .forgotPassword(email)
      .pipe(finalize(() => this.isLoadingSubject.next(false)));
  }

  // private methods
  private setAuthFromLocalStorage(auth: AuthModel): boolean {
    // store auth authToken/refreshToken/epiresIn in local storage to keep user logged in between page refreshes
    if (auth && auth.authToken) {
      localStorage.setItem(this.authLocalStorageToken, JSON.stringify(auth));
      return true;
    }
    return false;
  }

  public getAuthFromLocalStorage(): AuthModel | undefined {
    try {
      const lsValue = localStorage.getItem(this.authLocalStorageToken);
      if (!lsValue) {
        return undefined;
      }

      const authData = JSON.parse(lsValue);
      return authData;
    } catch (error) {
      console.error(error);
      return undefined;
    }
  }

  ngOnDestroy() {
    this.unsubscribe.forEach((sb) => sb.unsubscribe());
  }
  
  
  
  
  
  
  
  
  
  alldepositaddress222(): Observable<any> {
    const auth = this.getAuthFromLocalStorage();
    if (!auth || !auth.authToken) {
      return of(undefined);
    }

    this.isLoadingSubject.next(true);
    
	return this.authHttpService.alldepositaddress(auth.authToken);
	
	
  }
  
  
  
  
  
  
  
  
  
  




  // Support
    
addticket(data: any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.addticket(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

  ticket_list(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.ticket_list(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }


ticket_addmessage(data: any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.ticket_addmessage(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }


   ticket_by_id(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.ticket_by_id(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }


 getticket_message(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.getticket_message(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }


  // Add Plan

   investments_plans(): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.investments_plans(auth.authToken).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }
   addinvestmentplan(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.addinvestmentplan(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }

 delete_plan(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.delete_plan(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }
 editplanbyid(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.editplanbyid(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }
 updateinvestmentplan(data:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.updateinvestmentplan(auth.authToken,data).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }
  
  
  
  investmentsreportbyid(id:any): Observable<any> {


   const auth  = this.getAuthFromLocalStorage();
     if (!auth || !auth.authToken) {
      return of(undefined);
    }

   
   
    this.isLoadingSubject.next(true);
  
  
   var token=auth.authToken;
  
 
  
  return this.authHttpService.investmentsreportbyid(auth.authToken,id).pipe(
      map((data: any) => {
        if (data) {
          this.currentUserSubject.next(data);
        } else {
          this.logout();
        }
        return data;
      }),
      finalize(() => this.isLoadingSubject.next(false))
    );

  }
  
  
  
  
  
  
  
  
  
  isAuthenticated() {
    return localStorage.getItem('token') !== null;

  }
  
  isSuperAdminAuthenticated2() {
    let roll  = JSON.parse(window.localStorage.getItem("roll")!);

    return parseInt(roll) == 12;

  }
  
  isAdmin3() {
    let roll = JSON.parse(window.localStorage.getItem("roll")!);

    return parseInt(roll)  >  9 ;

  }

  isAdmin() {

    if( localStorage.getItem('token') !== null)
{

    let roll = JSON.parse(window.localStorage.getItem("roll")!);

    return parseInt(roll)  >   9;
}

  }


  isUser() {

    if( localStorage.getItem('token') !== null)
{

    let roll = JSON.parse(window.localStorage.getItem("roll")!);

    return parseInt(roll) <  9;
}

  }
 

  getToken() {
    return localStorage.getItem('token');




  }
  
}
