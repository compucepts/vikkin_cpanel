import { Component } from '@angular/core';

@Component({
  selector: 'app-connections',
  templateUrl: './connections.component.html',
})
export class ConnectionsComponent {
  constructor() {}
}
